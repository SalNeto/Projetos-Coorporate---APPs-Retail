﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System.ServiceProcess;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Upload_NFe_Cone
{
    class Program
    {
        static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                // Run as a console application
                Console.WriteLine("Executando pelo console do aplicativo...");
                var service = new InvoiceService();
                service.ProcessInvoiceData(CancellationToken.None).Wait();
                Console.WriteLine("Pressione qualquer tecla para sair...");
                Console.ReadKey();
            }
            else
            {
                // Executar como serviço do Windows
                ServiceBase[] servicesToRun = new ServiceBase[]
                {
                    new InvoiceService()
                };
                ServiceBase.Run(servicesToRun);
            }
        }
    }

    public class InvoiceService : ServiceBase
    {
        private CancellationTokenSource cancellationTokenSource;

        public InvoiceService()
        {
            cancellationTokenSource = new CancellationTokenSource();
        }

        protected override void OnStart(string[] args)
        {
            Task.Run(() => ProcessInvoiceData(cancellationTokenSource.Token));
        }

        protected override void OnStop()
        {
            Stop();
            Dispose();
        }

        public async Task ProcessInvoiceData(CancellationToken cancellationToken)
        {
            int retries = 0;
            const int maxRetries = 5; // Número máximo de tentativas antes de reiniciar o processo

            // Define o limite de itens por página
            int limit = 100;




            // Dados de autenticação da API
            string apiKey = "UO86dUKpK6RuOikxPkXA5aQSdLXK3xGq";

            // Configuração da requisição para a API
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("x-api-key", apiKey);

            // Definindo o timeout para 5 minutos 
            httpClient.Timeout = TimeSpan.FromMinutes(5);

            // Faz a primeira chamada para obter o número total de itens
            var initialPayload = new { limit = 1, page = 1, count = true };
            var initialContent = new StringContent(JsonConvert.SerializeObject(initialPayload), Encoding.UTF8, "application/json");
            var initialResponse = await httpClient.PostAsync("https://api.contabilone.com/invoices", initialContent);
            var initialResponseContent = await initialResponse.Content.ReadAsStringAsync();
            dynamic initialParsedResponse = JsonConvert.DeserializeObject(initialResponseContent);

            Console.WriteLine("Resposta recebida da API:");
            Console.WriteLine(initialResponseContent);  // Log para mostrar a resposta completa da API

            // Fazendo o parse da resposta
            int totalItems = 0;
            if (initialParsedResponse != null && initialParsedResponse.totalItems > 0)
            {
                totalItems = initialParsedResponse.totalItems;
                Console.WriteLine("Total de itens: " + totalItems);
            }
            else
            {
                Console.WriteLine("Erro ao capturar totalItems da resposta.");
            }

            int totalPages = (int)Math.Ceiling((double)totalItems / limit);
            Console.WriteLine("Total de Páginas: " + totalPages);

            bool shouldExit = false;
            // Realiza uma requisição para cada página
            int totalPagesProcessed = 0; // Variável para contar o número de páginas processadas

            for (int page = 1; page <= totalPages; page++)
            {
                if (page % 100 == 0)
                {
                    Console.WriteLine("Aguardando 1 minuto...");
                    Thread.Sleep(60000);
                }

                if (cancellationToken.IsCancellationRequested)
                {
                    Console.WriteLine("Task has been canceled.");
                    break;
                }

                bool pageRequestSuccessful = false;

                while (!pageRequestSuccessful)
                {
                    try
                    {
                        // Formatar as datas corretamente
                        var startDate = DateTime.Now.AddDays(-4).ToString("yyyy-MM-ddTHH:mm:ss");
                        var endDate = DateTime.Now.AddHours(-3).ToString("yyyy-MM-ddTHH:mm:ss");

                        var requestPayload = new
                        {
                            limit = limit,
                            count = true,
                            page = page,
                            filters = new[]
                            {
                                        new
                                        {
                                            name = "ide.dhEmi",
                                            type = "range",
                                            values = new[]
                                            {
                                                new
                                                {
                                                    start = startDate.ToString(), //("2024-12-01T00:00:00"),//
                                                    end = endDate.ToString() //("2024-12-01T23:59:59") //
                                                }
                                            }
                                        }
                                    }
                        };

                        // Imprimir o JSON para verificar o conteúdo
                        var jsonPayload = JsonConvert.SerializeObject(requestPayload, Formatting.Indented);                        
                        Console.WriteLine("JSON Payload enviado para API:");
                        Console.WriteLine(jsonPayload); // Exibe o JSON formatado para verificar no console

                        var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                        var response = await httpClient.PostAsync("https://api.contabilone.com/invoices", content);
                        var responseContent = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Conteúdo da resposta da API:");
                        Console.WriteLine(responseContent);

                        if (responseContent.Contains("The api client token is making too many requests"))
                        {
                            Console.WriteLine("A API retornou um erro: The api client token is making too many requests. Aguardando 6 minutos antes de tentar novamente...");
                            await Task.Delay(TimeSpan.FromMinutes(6));
                        }
                        else
                        {
                            dynamic parsedResponse = JsonConvert.DeserializeObject(responseContent);
                            if (parsedResponse != null && parsedResponse.totalItems != null)
                            {
                                totalItems = parsedResponse.totalItems;
                                totalPages = (int)Math.Ceiling((double)totalItems / limit);
                            }

                            List<InvoiceData> invoiceDataList = new List<InvoiceData>();
                            if (parsedResponse != null && parsedResponse.message != null)
                            {
                                IEnumerable<dynamic> messageItems = parsedResponse.message.ToObject<IEnumerable<dynamic>>();
                                foreach (var item in messageItems)
                                {
                                    if (item != null && item.emit != null && item.createdAt != null && item.ide != null && item.events != null && item.events.authorization != null && item.chNFe != null)
                                    {
                                        var invoiceData = new InvoiceData
                                        {
                                            SISTEMA_ORIGEM = "CONTABILONE",
                                            CNPJ = item?.emit?.CNPJ ?? string.Empty,
                                            InscricaoEstadual = item?.emit?.IE ?? string.Empty,
                                            Nome = item?.emit?.xFant ?? string.Empty,
                                            RequestId = item?.requestId ?? string.Empty,
                                            RemoteId = item?.events?.authorization?.remoteId ?? string.Empty,
                                            DataProcessamento = item?.createdAt?.formatted ?? string.Empty,
                                            Modelo = item?.ide?.mod ?? string.Empty,
                                            ChaveAcesso = item?.chNFe?.ToString() ?? string.Empty,
                                            STATUS_AUTORIZACAO = item?.events?.authorization?.status ?? string.Empty,
                                            Status_Contingencia = item?.events?.contingencyAuthorization?.status ?? string.Empty,
                                            Status_Inutilizacao = item?.events?.disablement?.status ?? string.Empty,
                                            Status_Cancelamento = item?.events?.cancelation?.status ?? string.Empty,
                                            vNF = item?.vNF != null ? item?.vNF.ToString("0.00") : "0.00",
                                            VBC = item?.total?.ICMSTot?.vBC != null ? item.total.ICMSTot.vBC.ToString("0.00") : "0.00",
                                            VICMS = item?.total?.ICMSTot?.vICMS != null ? item.total.ICMSTot.vICMS.ToString("0.00") : "0.00"
                                        };
                                        if (item?.events?.cancelation?.status == "AUTHORIZED")
                                        {
                                            invoiceData.Status = "CANCELADO";
                                        }
                                        else if (item?.events?.disablement?.status == "AUTHORIZED")
                                        {
                                            invoiceData.Status = "INUTILIZADO";
                                        }
                                        else if (item?.events?.contingencyAuthorization?.status == "AUTHORIZED")
                                        {
                                            invoiceData.Status = "AUTORIZACAO EM CONTINGENCIA";
                                        }
                                        else if (item?.events?.authorization?.status == "AUTHORIZED")
                                        {
                                            invoiceData.Status = "AUTORIZACAO NORMAL";
                                        }
                                        else
                                        {
                                            invoiceData.Status = item?.events?.authorization?.status ?? string.Empty;
                                        }
                                        invoiceDataList.Add(invoiceData);
                                    }
                                }
                                pageRequestSuccessful = true;// Indica que a requisição foi bem-sucedida
                            }

                            pageRequestSuccessful = true;

                            // Lógica de inserção no banco de dados...

                            // Conexão com o banco de dados Oracle SQL

                            var connectionString = "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.3.201.136)(PORT=1521)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=RJD14)));User ID=INTEGRA;Password=Int3gr4DUF;";
                            //var connectionString = "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.3.201.137)(PORT=1521)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=RJD14DSV)));User ID=SYNCHRO;Password=synchro;";

                            using (var connection = new OracleConnection(connectionString))
                            {
                                connection.Open();

                                foreach (var invoiceData in invoiceDataList)
                                {
                                    try
                                    {
                                        using (var command = new OracleCommand("DELETE FROM synchro.requisicao_sefaz WHERE CHAVE_DE_ACESSO = :chaveAcesso", connection))
                                        {
                                            command.Parameters.Add("chaveAcesso", invoiceData.ChaveAcesso);
                                            command.ExecuteNonQuery();
                                        }




                                        using (var command = new OracleCommand("INSERT INTO synchro.requisicao_sefaz (SISTEMA_ORIGEM, CNPJ, INSCRIÇÃO_ESTADUAL, NOME, REQUEST_ID, REMOTE_ID, DATA_DO_PROCESSAMENTO, MODELO, CHAVE_DE_ACESSO, STATUS, VNF, VBC, VICMS, VICMSDESON, VFCPUFDEST, VICMSUFDEST, VICMSUFREMET, VFCP, VBCST, VST, VFCPST, VFCPSTRET, VPROD, VFRETE, VSEG, VDESC, VII, VIPI, VIPIDEVOL, VPIS, VCOFINS, VOUTRO, STATUS_AUTORIZACAO, STATUS_CONTINGENCIA, STATUS_INUTILIZACAO, STATUS_CANCELAMENTO) " +
                                                                              "VALUES (:SISTEMA_ORIGEM, :cnpj, :inscricaoEstadual, :nome, :requestId, :remoteId, :dataProcessamento, :modelo, :chaveAcesso, :status, :vNF, :VBC, :VICMS, :VICMSDESON, :VFCPUFDEST, :VICMSUFDEST, :VICMSUFREMET, :VFCP, :VBCST, :VST, :VFCPST, :VFCPSTRET, :VPROD, :VFRETE, :VSEG, :VDESC, :VII, :VIPI, :VIPIDEVOL, :VPIS, :VCOFINS, :VOUTRO, :STATUS_CONTINGENCIA, :STATUS_AUTORIZACAO, :STATUS_INUTILIZACAO, :STATUS_CANCELAMENTO)", connection))

                                        {
                                            command.Parameters.Add("SISTEMA_ORIGEM", invoiceData.SISTEMA_ORIGEM);
                                            command.Parameters.Add("cnpj", invoiceData.CNPJ);
                                            command.Parameters.Add("inscricaoEstadual", invoiceData.InscricaoEstadual);
                                            command.Parameters.Add("nome", invoiceData.Nome);
                                            command.Parameters.Add("requestId", invoiceData.RequestId);
                                            command.Parameters.Add("remoteId", invoiceData.RemoteId);
                                            command.Parameters.Add("dataProcessamento", DateTime.ParseExact(invoiceData.DataProcessamento, "dd/MM/yyyy - HH:mm:ss", CultureInfo.InvariantCulture));
                                            command.Parameters.Add("modelo", invoiceData.Modelo);
                                            command.Parameters.Add("chaveAcesso", invoiceData.ChaveAcesso);
                                            command.Parameters.Add("status", invoiceData.Status);
                                            //decimal vNFValue = Convert.ToDecimal(invoiceData.vNF, CultureInfo.GetCultureInfo("pt-BR"));
                                            //decimal vNFValueInDatabase = vNFValue / 100;

                                            //command.Parameters.Add("vNF", vNFValueInDatabase);

                                            command.Parameters.Add("vNF", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.vNF) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.vNF ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);

                                            command.Parameters.Add("VBC", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VBC) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VBC ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);

                                            command.Parameters.Add("VICMS", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VICMS) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VICMS ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VICMSDESON", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VICMSDESON) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VICMSDESON ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VFCPUFDEST", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VFCPUFDEST) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VFCPUFDEST ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VICMSUFDEST", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VICMSUFDEST) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VICMSUFDEST ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VICMSUFREMET", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VICMSUFREMET) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VICMSUFREMET ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VFCP", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VFCP) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VFCP ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VBCST", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VBCST) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VBCST ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VST", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VST) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VST ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VFCPST", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VFCPST) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VFCPST ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VFCPSTRET", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VFCPSTRET) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VFCPSTRET ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VPROD", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VPROD) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VPROD ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VFRETE", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VFRETE) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VFRETE ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VSEG", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VSEG) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VSEG ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VDESC", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VDESC) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VDESC ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VII", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VII) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VII ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VIPI", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VIPI) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VIPI ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VIPIDEVOL", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VIPIDEVOL) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VIPIDEVOL ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VPIS", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VPIS) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VPIS ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VCOFINS", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VCOFINS) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VCOFINS ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);
                                            command.Parameters.Add("VOUTRO", OracleDbType.Decimal).Value = string.IsNullOrEmpty(invoiceData.VOUTRO) ? DBNull.Value : (object)decimal.Parse(Regex.Replace(invoiceData.VOUTRO ?? "0", @"[^\d.]", ""), CultureInfo.InvariantCulture);

                                            command.Parameters.Add("STATUS_AUTORIZACAO", invoiceData.STATUS_AUTORIZACAO);
                                            command.Parameters.Add("Status_Contingencia", invoiceData.Status_Contingencia);
                                            command.Parameters.Add("Status_Inutilizacao", invoiceData.Status_Inutilizacao);
                                            command.Parameters.Add("Status_Cancelamento", invoiceData.Status_Cancelamento);


                                            command.ExecuteNonQuery();
                                            Console.WriteLine("Processo executado com sucesso: " + invoiceData.ChaveAcesso);




                                        }

                                    }
                                    catch (System.AccessViolationException ex)
                                    {
                                        Console.WriteLine("Erro de acesso à memória protegida: " + ex.Message);
                                        // Reduz o contador da página para repetir a mesma página
                                        page--;
                                        break; // Sai do loop atual
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Ocorreu um erro ao processar os dados: " + ex.Message);
                                        // Reduz o contador da página para repetir a mesma página

                                        page--;
                                        break; // Sai do loop atual
                                    }
                                }

                                connection.Close();
                            }



                            Console.WriteLine("Processo executado com sucesso na página: " + page + " Total de paginas: " + totalPages);
                            // Pausa a execução por 3 minutos
                            //await Task.Delay(TimeSpan.FromMinutes(3));                                                            



                        }
                    }
                    catch (TaskCanceledException)
                    {
                        retries++;
                        Console.WriteLine($"Timeout detectado, aguardando 6 minutos antes de reiniciar. Tentativa {retries}/{maxRetries}");
                        await Task.Delay(TimeSpan.FromMinutes(6));

                        if (retries >= maxRetries)
                        {
                            Console.WriteLine("Número máximo de tentativas excedido. Finalizando o processo.");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Erro inesperado: {ex.Message}");
                        break;
                    }
                }
            }


        }
    }

    class InvoiceData
    {
        public string SISTEMA_ORIGEM { get; set; }
        public string CNPJ { get; set; }
        public string InscricaoEstadual { get; set; }
        public string Nome { get; set; }
        public string RemoteId { get; set; }
        public string RequestId { get; set; }
        public string DataProcessamento { get; set; }
        public string Modelo { get; set; }
        public string ChaveAcesso { get; set; }
        public string Status { get; set; }
        public string vNF { get; set; }
        public string STATUS_AUTORIZACAO { get; set; }
        public string Status_Contingencia { get; set; }
        public string Status_Inutilizacao { get; set; }
        public string Status_Cancelamento { get; set; }
        public string VBC { get; set; }
        public string VICMS { get; set; }
        public string VICMSDESON { get; set; }
        public string VFCPUFDEST { get; set; }
        public string VICMSUFDEST { get; set; }
        public string VICMSUFREMET { get; set; }
        public string VFCP { get; set; }
        public string VBCST { get; set; }
        public string VST { get; set; }
        public string VFCPST { get; set; }
        public string VFCPSTRET { get; set; }
        public string VPROD { get; set; }
        public string VFRETE { get; set; }
        public string VSEG { get; set; }
        public string VDESC { get; set; }
        public string VII { get; set; }
        public string VIPI { get; set; }
        public string VIPIDEVOL { get; set; }
        public string VPIS { get; set; }
        public string VCOFINS { get; set; }
        public string VOUTRO { get; set; }
    }
}
