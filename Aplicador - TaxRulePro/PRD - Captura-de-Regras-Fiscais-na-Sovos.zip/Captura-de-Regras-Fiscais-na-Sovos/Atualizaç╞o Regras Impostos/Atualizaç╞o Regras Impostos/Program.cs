﻿using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

class Program
{
    static async Task Main()
    {
        var inputPath = @"C:\Temp_Arq_Calc_Tax\Arq_Cone\IN";
        string outputPath = Path.Combine(inputPath, "Processed");
        string errorPath = Path.Combine(inputPath, "Erro");

        string[] inputFilePaths = Directory.GetFiles(inputPath);

        if (inputFilePaths.Length == 0)
        {
            Console.WriteLine("Nenhum arquivo de entrada encontrado.");
            return;
        }

        var apiKey = "UO86dUKpK6RuOikxPkXA5aQSdLXK3xGq";

        /// int maxParallelism = Math.Min(Environment.ProcessorCount, 500); // Limite máximo de 500, ajustado para o número de processadores disponíveis se menor
        int delayMilliseconds = 300; // Intervalo de tempo em milissegundos (0,0 segundos)

        // Configuração do bloco de fluxo de dados
        var dataflowOptions = new ExecutionDataflowBlockOptions
        {
            /// MaxDegreeOfParallelism = maxParallelism
            /// 
            MaxDegreeOfParallelism = Environment.ProcessorCount
        };

        var dataflowBlock = new ActionBlock<string>(async inputFilePath =>
        {
            using var client = new HttpClient();
            var url = "https://api.contabilone.com/rules-engine";
            ///var url = "https://api-homologation.contabilone.com/rules-engine"; ///--->> hml
            var contentType = "application/json";

            try
            {
                // Processa cada arquivo de entrada encontrado
                var lines = await File.ReadAllLinesAsync(inputFilePath);
                var json = string.Join(Environment.NewLine, lines);

                var outputFilePath = Path.Combine(outputPath, Path.GetFileName(inputFilePath));
                var errorFilePath = Path.Combine(errorPath, Path.GetFileName(inputFilePath));

                var content = new StringContent(json, Encoding.UTF8, contentType);
                content.Headers.Add("x-api-key", apiKey);

                var response = await client.PostAsync(url, content);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var responseFilePath = Path.Combine(outputPath, Path.GetFileNameWithoutExtension(inputFilePath) + ".resposta.json");
                    await File.WriteAllTextAsync(responseFilePath, responseBody);
                    File.Move(inputFilePath, outputFilePath);
                    Console.WriteLine($"Arquivo '{inputFilePath}' processado com sucesso.");
                }
                else
                {
                    var responseFilePath = Path.Combine(errorPath, Path.GetFileNameWithoutExtension(inputFilePath) + ".erro.json");
                    await Task.Delay(3000); // Pausa de 3000 milissegundos (3 segundos)
                    await File.WriteAllTextAsync(responseFilePath, responseBody);
                    File.Move(inputFilePath, errorFilePath);
                    Console.WriteLine($"Arquivo '{inputFilePath}' processado com erro.");
                }

                await Task.Delay(delayMilliseconds); // Pausa de acordo com o intervalo configurado
            }
            catch (Exception ex)
            {
                var errorFilePath = Path.Combine(errorPath, Path.GetFileName(inputFilePath));
                await Task.Delay(3000); // Pausa de 3000 milissegundos (3 segundos)
                File.Move(inputFilePath, errorFilePath);
                var responseFilePath = Path.Combine(errorPath, Path.GetFileNameWithoutExtension(inputFilePath) + ".erro.json");
                Console.WriteLine($"Erro ao processar o arquivo '{inputFilePath}'. {ex.Message}");
            }
        }, dataflowOptions);

        foreach (var inputFilePath in inputFilePaths)
        {
            dataflowBlock.Post(inputFilePath);
        }

        dataflowBlock.Complete();
        await dataflowBlock.Completion;

        Console.WriteLine("Processamento concluído.");
    }
}
