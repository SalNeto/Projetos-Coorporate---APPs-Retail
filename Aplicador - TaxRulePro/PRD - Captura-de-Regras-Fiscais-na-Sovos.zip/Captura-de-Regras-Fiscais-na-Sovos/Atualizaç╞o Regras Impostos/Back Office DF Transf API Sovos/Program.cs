﻿// See https://aka.ms/new-console-template for more information

using System.IO;
using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

public class TransformacaoParaAPISovos
{
    private static readonly string fileNames = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN";
    private static readonly string searchPattern = "*BACKOFFICE_DutyFree*";
    private static readonly string processedFolder = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Processed";
    private static readonly string fileStore = @"C:\Temp_Arq_Calc_Tax\Arq_Cone\Versao_Regra";
    private static readonly string searchStore = "*historico_DutyFree*";
    private static readonly string requestPath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Request";

    public static void Main(string[] args)
    {
        string[] filePaths = Directory.GetFiles(fileNames, searchPattern);
        string[] fileStores = Directory.GetFiles(fileStore, searchStore);

        int codigo = GetCodigo(fileStores);
        Console.WriteLine($"Código encontrado: {codigo}");

        foreach (string filePath in filePaths)
        {
            if (IsFileLocked(filePath))
            {
                Console.WriteLine($"O arquivo {filePath} está sendo gravado ou em uso. Ignorando.");
                continue;
            }

            ProcessFile(filePath, codigo);
        }
    }

    private static int GetCodigo(string[] fileStores)
    {
        int codigo = 999;
        string filestorePath = fileStores.LastOrDefault();

        for (int attempt = 1; attempt <= 5 && codigo == 999; attempt++)
        {
            try
            {
                if (filestorePath == null || IsFileLocked(filestorePath))
                {
                    Console.WriteLine($"O arquivo {filestorePath} está sendo gravado ou em uso. Ignorando.");
                    continue;
                }

                string lastLine = File.ReadLines(filestorePath).LastOrDefault();
                if (!string.IsNullOrEmpty(lastLine))
                {
                    foreach (string line in File.ReadLines(filestorePath).Reverse())
                    {
                        string[] fields = line.Split('|');
                        if (fields.Length == 3 && fields.All(f => !string.IsNullOrWhiteSpace(f)))
                        {
                            if (int.TryParse(fields[2].Trim(), out var parsedCodigo))
                            {
                                codigo = parsedCodigo;
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Valor inválido na segunda posição. Utilizando valor padrão.");
                            }
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Erro ao acessar o arquivo {filestorePath}: {ex.Message}. Tentativa {attempt}/5. Aguardando nova tentativa...");
            }
        }

        return codigo;
    }

    private static bool IsFileLocked(string filePath)
    {
        try
        {
            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                return false;
            }
        }
        catch (IOException)
        {
            return true;
        }
    }

    private static void ProcessFile(string filePath, int codigo)
    {
        string fileContent = File.ReadAllText(filePath);
        string[] userInfo = fileContent.Split('|');

        string NCMString = (userInfo[0] == "LFDES" || userInfo[0] == "LFEM") &&
                           (userInfo[1] == "013" || userInfo[1] == "014" || userInfo[1] == "148" || userInfo[1] == "239" || userInfo[1] == "001") &&
                           (string.IsNullOrEmpty(userInfo[19]) || !int.TryParse(userInfo[19], out _))
                           ? "33030010"
                           : userInfo[19]?.PadLeft(8, '0') ?? "0";

        string indPresencaString = userInfo[4] == "S" ? "1" : "9";
        string CESTString = userInfo[21];

        destinatario destinatario;
        emitente emitente;

        if (filePath.Contains("001_Backoffice_DutyFree"))
        {
            destinatario = new destinatario
            {
                pessoaJuridica = userInfo[6],
                simplesNac = "N",
                regTribDiferenciado = new[] { userInfo[0] },
                contribuinteICMS = userInfo[7],
                contribuinteCOFINS = "S",
                contribuintePIS = "S",
                contribuinteII = "N",
                contribuinteIPI = "N",
                contribuinteISS = "N",
                contribuinteST = "N",
                cdPais = userInfo[1] == "013" || userInfo[1] == "048" || userInfo[1] == "148" ? "845" : "105",
                cdMunicipio = userInfo[16],
                uf = userInfo[17],
                cnpj = userInfo[14],
                inscricaoEstadual = userInfo[15],
                cdAtividadeEconomica = new[] { userInfo[18] }
            };

            emitente = new emitente
            {
                pessoaJuridica = userInfo[5],
                cdAtividadeEconomica = new[] { userInfo[13] },
                cnpj = userInfo[9],
                inscricaoEstadual = userInfo[10],
                simplesNac = "N",
                /// regTribDiferenciado = new[] { userInfo[0] },
                contribuinteCOFINS = "S",
                contribuintePIS = "S",
                contribuinteICMS = "S",
                contribuinteII = "N",
                contribuinteIPI = "N",
                contribuinteISS = "N",
                contribuinteST = "N",
                cdPais = "105",
                cdMunicipio = userInfo[11],
                uf = userInfo[12],
                nome = "",
                inscricaoMunicipal = ""
            };
        }
        else
        {
            destinatario = new destinatario
            {
                pessoaJuridica = userInfo[6],
                simplesNac = "N",
                contribuinteICMS = userInfo[7],
                contribuinteCOFINS = "S",
                contribuintePIS = "S",
                contribuinteII = "N",
                contribuinteIPI = "N",
                contribuinteISS = "N",
                contribuinteST = "N",
                cdPais = userInfo[1] == "013" || userInfo[1] == "048" || userInfo[1] == "148" ? "845" : "105",
                cdMunicipio = userInfo[16],
                uf = userInfo[17],
                cnpj = userInfo[14],
                inscricaoEstadual = userInfo[15],
                cdAtividadeEconomica = new[] { userInfo[18] }
            };

            emitente = new emitente
            {
                pessoaJuridica = userInfo[5],
                cdAtividadeEconomica = new[] { userInfo[13] },
                cnpj = userInfo[9],
                inscricaoEstadual = userInfo[10],
                simplesNac = "N",
                regTribDiferenciado = new[] { userInfo[0] },
                contribuinteCOFINS = "S",
                contribuintePIS = "S",
                contribuinteICMS = "S",
                contribuinteII = "N",
                contribuinteIPI = "N",
                contribuinteISS = "N",
                contribuinteST = "N",
                cdPais = "105",
                cdMunicipio = userInfo[11],
                uf = userInfo[12],
                nome = "",
                inscricaoMunicipal = ""
            };
        }

        var rootObject = new Rootobject
        {
            cdTipo = userInfo[2],
            dtEmissao = "",
            destinatario = destinatario,
            emitente = emitente,
            itensDocFiscal = new[]
            {
                new ItemDocFiscal
                {
                    prodItem = new prodItem
                    {
                        CEST = string.IsNullOrEmpty(CESTString) ? string.Empty : CESTString.PadLeft(7, '0'),
                        cdOrigem = string.IsNullOrEmpty(userInfo[25]) ? 2 : int.Parse(userInfo[25]),
                        codigo = codigo,
                        descricao = "Consulta Impostos",
                        EAN = "SEM GTIN",
                        NCM = NCMString,
                        exNCM = userInfo[20],
                        fabricacao = userInfo[1] == "001" ? "0" : "1",
                        aplicacao = userInfo[1] == "002" ? "U" : "C"
                    },
                    cdItemDocFiscal = int.Parse(userInfo[22]),
                    vlAliquotaICMSOperacaoAnterior = userInfo[23] ?? string.Empty,
                    CDU1 = userInfo[24] ?? string.Empty,
                    unidade = "UN",
                    vlTotal = 10.0,
                    vlUnitario = 10.00,
                    vlDesconto = 0.00,
                    qtItemDocFiscal = 1.0,
                    qtTributaria = 1.0,
                    qtTributariaUnidade = "UN",
                    cdClassificacao = "M",
                    deduzCEST = "N",
                    deduzCFOP = "S",
                    deduzCSTCOFINS = "S",
                    deduzCSTICMS = "S",
                    deduzCSTIPI = "S",
                    deduzCSTPIS = "S"
                }
            },
            naturezaOperacao = userInfo[1],
            indConsumidorFinal = userInfo[3],
            indPresenca = indPresencaString,
            tpDocFiscal = "FT",
            tpCalculo = userInfo[1] == "001" || userInfo[1] == "069" ? "REC" : "TAX",
            versaoNFe = "4.00",
            geraLog = "N",
            modelo = 55,
            serie = 100,
            numero = 1,
            CalcParam = new CalcParam { mdArred = "A", geraInc = "N" }
        };

        string json = System.Text.Json.JsonSerializer.Serialize(new[] { rootObject });
        string outputPath = Path.Combine(processedFolder, Path.GetFileName(filePath));
        File.Move(filePath, outputPath, true);

        string outputJsonPath = Path.Combine(requestPath, Path.GetFileName(filePath) + ".json");
        File.WriteAllText(outputJsonPath, json);
    }

    [JsonObject(NamingStrategyType = typeof(CamelCaseNamingStrategy), NamingStrategyParameters = new object[] { true, false })]
    public class Rootobject
    {
        public string cdTipo { get; set; }
        public string dtEmissao { get; set; }
        public destinatario destinatario { get; set; }
        public emitente emitente { get; set; }
        public ItemDocFiscal[] itensDocFiscal { get; set; }
        public CalcParam CalcParam { get; set; }
        public string geraLog { get; set; }
        public string naturezaOperacao { get; set; }
        public string tpCalculo { get; set; }
        public string indConsumidorFinal { get; set; }
        public string indPresenca { get; set; }
        public int numero { get; set; }
        public int serie { get; set; }
        public string tpDocFiscal { get; set; }
        public string versaoNFe { get; set; }
        public bool docFiscalTeste { get; set; }
        public int modelo { get; set; }
    }

    public class destinatario
    {
        public string pessoaJuridica { get; set; }
        public string[] cdAtividadeEconomica { get; set; }
        public string simplesNac { get; set; }
        public string[] regTribDiferenciado { get; set; }
        public string contribuinteICMS { get; set; }
        public string contribuinteCOFINS { get; set; }
        public string contribuinteII { get; set; }
        public string contribuinteIPI { get; set; }
        public string contribuinteISS { get; set; }
        public string contribuintePIS { get; set; }
        public string contribuinteST { get; set; }
        public string cpf { get; set; }
        public string cnpj { get; set; }
        public string cdPais { get; set; }
        public string cdMunicipio { get; set; }
        public string uf { get; set; }
        public string inscricaoEstadual { get; set; }
    }

    public class emitente
    {
        public string pessoaJuridica { get; set; }
        public string[] cdAtividadeEconomica { get; set; }
        public string cnpj { get; set; }
        public string inscricaoEstadual { get; set; }
        public string nome { get; set; }
        public string simplesNac { get; set; }
        public string[] regTribDiferenciado { get; set; }
        public string contribuinteCOFINS { get; set; }
        public string contribuinteICMS { get; set; }
        public string contribuinteII { get; set; }
        public string contribuinteIPI { get; set; }
        public string contribuinteISS { get; set; }
        public string contribuintePIS { get; set; }
        public string contribuinteST { get; set; }
        public string cdPais { get; set; }
        public string cdMunicipio { get; set; }
        public string uf { get; set; }
        public string inscricaoMunicipal { get; set; }
    }

    public class ItemDocFiscal
    {
        public prodItem prodItem { get; set; }
        public int cdItemDocFiscal { get; set; }
        public string vlAliquotaICMSOperacaoAnterior { get; set; }
        public string CDU1 { get; set; }
        public string unidade { get; set; }
        public double vlTotal { get; set; }
        public double vlUnitario { get; set; }
        public double vlDesconto { get; set; }
        public double qtItemDocFiscal { get; set; }
        public double qtTributaria { get; set; }
        public string qtTributariaUnidade { get; set; }
        public string cdClassificacao { get; set; }
        public string deduzCEST { get; set; }
        public string deduzCFOP { get; set; }
        public string deduzCSTCOFINS { get; set; }
        public string deduzCSTICMS { get; set; }
        public string deduzCSTIPI { get; set; }
        public string deduzCSTPIS { get; set; }
    }

    public class prodItem
    {
        public string? CEST { get; set; }
        public int cdOrigem { get; set; }
        public int codigo { get; set; }
        public string descricao { get; set; }
        public string EAN { get; set; }
        public string NCM { get; set; }
        public string exNCM { get; set; }
        public string fabricacao { get; set; }
        public string aplicacao { get; set; }
    }

    public class CalcParam
    {
        public string mdArred { get; set; }
        public string geraInc { get; set; }
    }
}
