﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace FileManagement
{
    class Program
    {
        const string sourceFolder = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN";
        const string waitingFolder = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Aguardando\";
        const int maxFiles = 500000;
        const int minFiles = 250000;
        const int batchSize = 25000;
        static bool isProcessing = false;

        static Dictionary<string, List<string>> fileCache = new Dictionary<string, List<string>>();

        static async Task Main(string[] args)
        {
            InitializeCache();
            while (true)
            {
                if (!isProcessing)
                {
                    isProcessing = true;
                    await ManageFilesAsync();
                    isProcessing = false;
                }
                await Task.Delay(30000); // Corrigido para 3 segundos de pausa como no código original
            }
        }

        static void InitializeCache()
        {
            var directories = new[] { sourceFolder }.Concat(Directory.GetDirectories(waitingFolder, "IN_*"));
            foreach (var dir in directories)
            {
                fileCache[dir] = Directory.GetFiles(dir).ToList();
            }
        }

        static async Task ManageFilesAsync()
        {
            int sourceFileCount = fileCache[sourceFolder].Count;

            string[] waitingFolders = {
                Path.Combine(waitingFolder, "IN_1"),
                Path.Combine(waitingFolder, "IN_2"),
                Path.Combine(waitingFolder, "IN_3"),
                Path.Combine(waitingFolder, "IN_4"),
                Path.Combine(waitingFolder, "IN_5"),
                Path.Combine(waitingFolder, "IN_6")
            };

            EnsureDirectoriesExist(waitingFolders);

            if (sourceFileCount > maxFiles)
            {
                await TransferFilesAsync(sourceFolder, waitingFolders, maxFiles);
            }
            else if (sourceFileCount < minFiles)
            {
                await ReturnFilesAsync(sourceFolder, waitingFolders, minFiles);
            }
        }

        static void EnsureDirectoriesExist(string[] directories)
        {
            foreach (var dir in directories)
            {
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
            }
        }

        static async Task TransferFilesAsync(string source, string[] destinations, int limit)
        {
            foreach (var dest in destinations)
            {
                int destFileCount = fileCache[dest].Count;
                int sourceFileCount = fileCache[source].Count;

                while (destFileCount < limit && sourceFileCount > limit)
                {
                    var filesToMove = fileCache[source].Take(Math.Min(batchSize, limit - destFileCount)).ToList();

                    var tasks = filesToMove.Select(file => Task.Run(() =>
                    {
                        string destFile = Path.Combine(dest, Path.GetFileName(file));
                        File.Move(file, destFile);
                        fileCache[dest].Add(destFile);
                        fileCache[source].Remove(file);
                    })).ToArray();

                    await Task.WhenAll(tasks);

                    destFileCount = fileCache[dest].Count;
                    sourceFileCount = fileCache[source].Count;

                    if (sourceFileCount <= limit)
                    {
                        break;
                    }
                }
            }
        }

        static async Task ReturnFilesAsync(string source, string[] destinations, int limit)
        {
            foreach (var dest in destinations)
            {
                int destFileCount = fileCache[dest].Count;
                int sourceFileCount = fileCache[source].Count;

                while (destFileCount > 0 && sourceFileCount < limit)
                {
                    var filesToMove = fileCache[dest].Take(Math.Min(batchSize, limit - sourceFileCount)).ToList();

                    var tasks = filesToMove.Select(file => Task.Run(() =>
                    {
                        string sourceFile = Path.Combine(source, Path.GetFileName(file));
                        File.Move(file, sourceFile);
                        fileCache[source].Add(sourceFile);
                        fileCache[dest].Remove(file);
                    })).ToArray();

                    await Task.WhenAll(tasks);

                    destFileCount = fileCache[dest].Count;
                    sourceFileCount = fileCache[source].Count;

                    if (sourceFileCount >= limit)
                    {
                        break;
                    }
                }
            }
        }
    }
}
