﻿using System;
using System.Diagnostics;
using System.IO;

class Program
{
    static void Main()
    {
        System.Threading.Thread.Sleep(50000); // espera por 5 segundos antes de iniciar o código

        var diretorio = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Responser";
        var arquivoPadrao = "C*";
        var processo = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Transformação_C_One.exe");

        int tentativas = 0;
        int maxTentativas = 10;

        while (Directory.GetFiles(diretorio, arquivoPadrao).Length > 0)
        {
            Console.WriteLine("Arquivo encontrado. Iniciando processo...");

            var info = new ProcessStartInfo(processo)
            {
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };

            Process p = new Process();
            p.StartInfo = info;
            p.EnableRaisingEvents = true;
            p.OutputDataReceived += (sender, e) => Console.WriteLine(e.Data);
            p.Start();
            p.BeginOutputReadLine();

            // envia uma mensagem para o processo indicando o caminho do arquivo a ser processado
           // p.StandardInput.WriteLine(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Inicialização_Looping.exe"));

            p.WaitForExit();

            if (p.ExitCode == 0)
            {
                // O processo terminou com sucesso
                Console.WriteLine("O processo foi concluído com sucesso.");
            }
            else
            {
                // O processo falhou, então reinicie
                Console.WriteLine("O processo falhou. Reiniciando...");
            }

            tentativas++;

            if (tentativas == maxTentativas)
            {
                Console.WriteLine("O processo não foi concluído após {0} tentativas.", maxTentativas);
                break;
            }
        }
    }
}
