﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string inputDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata";
        string outputDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN_line_2";
        string processedDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Processed";
        string searchKeyword = "Backoffice_DutyPaid_MasterDataBP-202407020820141";

        while (true)
        {
            // Obtém a lista de arquivos no diretório de entrada
            string[] inputFiles = Directory.GetFiles(inputDirectory);

            if (inputFiles.Length == 0)
            {
                Console.WriteLine("Nenhum arquivo para processar. Aguardando 5 minutos...");
                await Task.Delay(5 * 60 * 1000); // Aguarda 5 minutos antes de verificar novamente
                continue;
            }

            var tasks = inputFiles.Select(async (inputFile) =>
            {
                string fileName = Path.GetFileNameWithoutExtension(inputFile);

                if (fileName.Contains(searchKeyword, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Processando arquivo: {inputFile}");

                    // Verificar se o diretório de destino existe, senão, criá-lo
                    if (!Directory.Exists(processedDirectory))
                    {
                        Directory.CreateDirectory(processedDirectory);
                    }

                    // Verificar se o arquivo de destino já existe e excluí-lo, se necessário
                    string processedFilePath = Path.Combine(processedDirectory, Path.GetFileName(inputFile));
                    if (File.Exists(processedFilePath))
                    {
                        File.Delete(processedFilePath);
                    }

                    // Fraciona o arquivo e grava suas frações no diretório de saída
                    await SplitAndSaveFileAsync(inputFile, outputDirectory);

                    // Move o arquivo original para o diretório de processados
                    File.Move(inputFile, processedFilePath);

                    Console.WriteLine($"Arquivo processado: {inputFile}");
                }
            });

            await Task.WhenAll(tasks);
        }
    }

    static async Task SplitAndSaveFileAsync(string filePath, string outputDirectory)
    {
        string[] lines = await File.ReadAllLinesAsync(filePath);
        string fileName = Path.GetFileNameWithoutExtension(filePath);
        string fileExtension = Path.GetExtension(filePath);

        var tasks = lines.Select((line, index) =>
        {
            return Task.Run(async () =>
            {
                string trimmedLine = line.TrimEnd(); // Remove espaços no final da linha

                if (!string.IsNullOrWhiteSpace(trimmedLine))
                {
                    string outputFilePath = Path.Combine(outputDirectory, $"{fileName}_line_{index + 1}{fileExtension}");
                    await File.WriteAllTextAsync(outputFilePath, trimmedLine);
                }
            });
        });

        await Task.WhenAll(tasks);
    }
}
