﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System;
using System.IO;
using System.Text.Json.Nodes;
using System.ComponentModel.Design;
using System.Linq;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Text;
using System.Diagnostics.Metrics;
using System.Runtime.ConstrainedExecution;

public class Program
{
    public static void Main(string[] args)
    {







        System.Threading.Thread.Sleep(0000); // espera por 5 segundos antes de iniciar o código

        // Restante do seu código aqui



        string inputFilePath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Responser";
        var outputPath = @"C:\Temp_Arq_Calc_Tax\Arq_Cone\IN";
        var processedPath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Responser\Processed";
        // Define o padrão de busca para os arquivos de entrada
        string searchPattern = "*";
        // Busca os arquivos que correspondem ao padrão de busca
        string[] jsonFilePaths = Directory.GetFiles(inputFilePath, searchPattern);


        foreach (string jsonFilePath in jsonFilePaths)
        {

            if (File.Exists(jsonFilePath))
            {
                // Define o nome do arquivo de saída como o mesmo do arquivo de entrada
                var outputFilePath = Path.Combine(outputPath, Path.GetFileName(jsonFilePath));



                // Processa o arquivo de entrada e gera o arquivo de saída
                // ...
                string json_Sovos = File.ReadAllText(jsonFilePath);





                try
                {
                    dynamic deserializedJson = JsonConvert.DeserializeObject<dynamic>(json_Sovos);
                    dynamic firstElement = deserializedJson[0];
                    dynamic emitente = deserializedJson[0].emitente;
                    dynamic destinatario = deserializedJson[0].destinatario;
                    dynamic itensDocFiscal = deserializedJson[0].itensDocFiscal[0];
















                    // Objeto de modelo para preencher
                    // Em algum lugar do seu código:
                    int maxConsequences = 63; // defina o número máximo de consequências aqui
                    int maxConditions = 19;
                    int maxlegalBase = 14;

                    Modelo modelo = new Modelo(maxlegalBase, maxConditions, maxConsequences);

                    // Preenche o modelo com os campos mapeados




                    string transacao;
                    if (firstElement.naturezaOperacao?.ToString() == "002")
                    {
                        transacao = "Venda de Mercadorias";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "014")
                    {
                        transacao = "Transferencia de Mercadorias";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "001")
                    {
                        transacao = "Entrada por compra de mercadoria";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "005")
                    {
                        transacao = "Devolucao de Compra";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "009")
                    {
                        transacao = "Ajuste de Inventario - Destruição";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "010")
                    {
                        transacao = "Ajuste de inventario - Faltas";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "012")
                    {
                        transacao = "Devolução de Venda";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "015")
                    {
                        transacao = "Devolucao de mer. consig.";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "034")
                    {
                        transacao = "Remessa para Venda Fora do Estab";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "041")
                    {
                        transacao = "Retorno de Remessa para Venda Fora do Estab";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "048")
                    {
                        transacao = "Outras Saidas nao Especificadas";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "059")
                    {
                        transacao = "Outras Entradas nao Especificadas";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "068")
                    {
                        transacao = "Entrada de Bonificacao";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "069")
                    {
                        transacao = "Entrada de mercadoria recebida em consig";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "074")
                    {
                        transacao = "Compra de mercadoria recebida em consignacao";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "087")
                    {
                        transacao = "Ajuste de inventario - sobras";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "103")
                    {
                        transacao = "Venda de mercadoria, efetuada fora do estabelecimento";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "109")
                    {
                        transacao = "Devolucao de Venda com CF";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "183")
                    {
                        transacao = "Baixa de estoque para consumo interno";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "100")
                    {
                        transacao = "Devolucao Simbolica Merc em Consignacao";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "091")
                    {
                        transacao = "Devolucao de Transferencia";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "125")
                    {
                        transacao = "Operacao Perda e Extravios";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "239")
                    {
                        transacao = "RQA Emissao de nota";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "013")
                    {
                        transacao = "Importacao de Mercadoria";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "026")
                    {
                        transacao = "Rem. para vda. fora estabelec. sujeito a subst. tributaria";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "148")
                    {
                        transacao = "Exportacao Direta";
                    }
                    else
                    if (firstElement.naturezaOperacao?.ToString() == "175")
                    {
                        transacao = "Entrada em transferencia para comercializacao";
                    }
                    else
                    {
                        transacao = "Add Transacao";
                    }





                    string uf_origem = ""; // inicialização da variável
                    string uf_destino = "";
                    string versao_componente = firstElement.componentVersion?.ToString() ?? "Versão não informada";




                    if ((emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count == 1 && emitente.regTribDiferenciado[0] == "") || (destinatario.regTribDiferenciado != null && destinatario.regTribDiferenciado.Count == 1 && destinatario.regTribDiferenciado[0] == ""))
                    {
                        modelo.accountId = "224e75d8-16b0-4113-b20c-54a8576f4ccd";
                        modelo.baseId = itensDocFiscal.prodItem.codigo.ToString();///versao teste 355 "rt-dutypaid:" + versao_componente;
                        modelo.baseId = modelo.baseId.Replace("\"", ""); // Remove as aspas duplas

                        int baseIdNumero;
                        bool conversaoSucesso = int.TryParse(modelo.baseId, out baseIdNumero);

                        uf_origem = emitente.uf?.ToString() ?? "UF não informada";
                        uf_destino = destinatario.uf?.ToString() ?? "UF não informada";
                    }
                    else if (destinatario.regTribDiferenciado != null && destinatario.regTribDiferenciado.Count > 0)
                    {
                        bool encontrouLF = false;

                        foreach (var valor in (destinatario.regTribDiferenciado))
                        {
                            if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                            {
                                modelo.accountId = "f52d32c7-7691-4676-a34d-12842823c048";
                                modelo.baseId = itensDocFiscal.prodItem.codigo.ToString();///versao teste 13 "rt-dutyfree:" + versao_componente;
                                modelo.baseId = modelo.baseId.Replace("\"", ""); // Remove as aspas duplas

                                int baseIdNumero;
                                bool conversaoSucesso = int.TryParse(modelo.baseId, out baseIdNumero);

                                uf_origem = "Ambito_Nacional";
                                uf_destino = "Ambito_Nacional";
                                encontrouLF = true;
                                break;
                            }
                        }

                        if (!encontrouLF)
                        {
                            modelo.accountId = "224e75d8-16b0-4113-b20c-54a8576f4ccd";
                            modelo.baseId = itensDocFiscal.prodItem.codigo.ToString();///versao teste 355 "rt-dutypaid:" + versao_componente                       
                            modelo.baseId = modelo.baseId.Replace("\"", ""); // Remove as aspas duplas

                            int baseIdNumero;
                            bool conversaoSucesso = int.TryParse(modelo.baseId, out baseIdNumero);


                            uf_origem = emitente.uf?.ToString() ?? "UF não informada";
                            uf_destino = destinatario.uf?.ToString() ?? "UF não informada";
                        }
                    }
                    else 
                    if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0)
                    {
                        bool encontrouLF = false;

                        foreach (var valor in emitente.regTribDiferenciado)
                        {
                            if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                            {
                                modelo.accountId = "f52d32c7-7691-4676-a34d-12842823c048";
                                modelo.baseId = itensDocFiscal.prodItem.codigo.ToString();///versao teste 13 "rt-dutyfree:" + versao_componente;
                                modelo.baseId = modelo.baseId.Replace("\"", ""); // Remove as aspas duplas

                                int baseIdNumero;
                                bool conversaoSucesso = int.TryParse(modelo.baseId, out baseIdNumero);

                                uf_origem = "Ambito_Nacional";
                                uf_destino = "Ambito_Nacional";
                                encontrouLF = true;
                                break;
                            }
                        }

                        if (!encontrouLF)
                        {
                            modelo.accountId = "224e75d8-16b0-4113-b20c-54a8576f4ccd";
                            modelo.baseId = itensDocFiscal.prodItem.codigo.ToString();///versao teste 355 "rt-dutypaid:" + versao_componente                       
                            modelo.baseId = modelo.baseId.Replace("\"", ""); // Remove as aspas duplas

                            int baseIdNumero;
                            bool conversaoSucesso = int.TryParse(modelo.baseId, out baseIdNumero);


                            uf_origem = emitente.uf?.ToString() ?? "UF não informada";
                            uf_destino = destinatario.uf?.ToString() ?? "UF não informada";
                        }
                    }




                    string title_completo = string.Concat(transacao, "|", uf_origem, "|", uf_destino, "| Versao_TaxRules: ", versao_componente);
                    modelo.title = title_completo;
                    Console.WriteLine(title_completo);
                    modelo.description = title_completo;


                    // Defina o identificador do fuso horário do Brasil
                    string timeZoneId = "E. South America Standard Time"; // Fuso horário de Brasília

                    // Obtenha a hora atual no fuso horário do Brasil
                    DateTime currentTimeBrasil = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, timeZoneId);

                    // Formate a hora atual no formato desejado
                    string formattedDateTime = currentTimeBrasil.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    // Atribua o valor formatado ao modelo.startDate
                    modelo.startDate = formattedDateTime;
                    ///modelo.startDate = firstElement.dtEmissao.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

                    modelo.onConflict = "REPLACE";






                    string dsSigla_ICMS = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "ICMS")
                        {
                            dsSigla_ICMS = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_ICMS = "Sem_Tributacao_de_ICMS";
                        }

                    }



                    string dsSigla_FCPICM = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "FCPICM")
                        {
                            dsSigla_FCPICM = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_FCPICM = "Sem_Tributacao_de_FCPICM";
                        }
                    }


                    string dsSigla_ST = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "ST")
                        {
                            dsSigla_ST = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_ST = "Sem_Tributacao_de_ST";
                        }
                    }


                    string dsSigla_PIS = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "PIS")
                        {
                            dsSigla_PIS = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_PIS = "Sem_Tributacao_de_PIS";
                        }
                    }

                    string dsSigla_COFINS = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "COFINS")
                        {
                            dsSigla_COFINS = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_COFINS = "Sem_Tributacao_de_COFINS";
                        }
                    }



                    string dsSigla_IPI = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "IPI")
                        {
                            dsSigla_IPI = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_IPI = "Sem_Tributacao_de_IPI";
                        }
                    }




                    string dsSigla_II = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "II")
                        {
                            dsSigla_II = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_II = "Sem_Tributacao_de_II";
                        }
                    }

                    string dsSigla_DIFAL = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "DIFAL")
                        {
                            dsSigla_DIFAL = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_DIFAL = "Sem_Tributacao_de_DIFAL";
                        }
                    }

                    string dsSigla_FCPDIF = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "FCPDIF")
                        {
                            dsSigla_FCPDIF = enquadramento.dsSigla.ToString(CultureInfo.InvariantCulture);
                            break;
                        }
                        else
                        {
                            dsSigla_FCPDIF = "Sem_Tributacao_de_FCPDIF";
                        }
                    }

                    modelo.keywords = new string[] { dsSigla_ICMS, dsSigla_FCPICM, dsSigla_ST, dsSigla_DIFAL, dsSigla_FCPDIF, dsSigla_PIS, dsSigla_COFINS, dsSigla_IPI, dsSigla_II };


                    string baselegal_tax_name_icms = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "ICMS" && enquadramento.observacaoFiscal != null)
                        {
                            ///baselegal_tax_name_icms = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            string observacaoFiscalSemCaracteresEspeciais = Regex.Replace(observacaoFiscal, @"[^\w\s]", "");
                            baselegal_tax_name_icms = observacaoFiscalSemCaracteresEspeciais.Length > 100 ? observacaoFiscalSemCaracteresEspeciais.Substring(0, 100) : observacaoFiscalSemCaracteresEspeciais;

                            modelo.consequences[50].variable = "NFe.infNFe.infAdic.infAdFisco";
                            modelo.consequences[50].value = "'" + baselegal_tax_name_icms + "'";


                            break;

                        }
                        else
                        {
                            baselegal_tax_name_icms = "Sem observacao legal na regra sovos para imposto ICMS";
                        }

                    }
                    modelo.legalBase[0].name = baselegal_tax_name_icms.ToString();


                    modelo.legalBase[0].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";



                    string baselegal_tax_name_FCPICM = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "FCPICM" && enquadramento.observacaoFiscal != null)
                        {

                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_FCPICM = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;

                            break;



                        }
                        else
                        {
                            baselegal_tax_name_FCPICM = "Sem observacao legal na regra sovos para imposto FCPICM";
                        }

                    }
                    modelo.legalBase[1].name = baselegal_tax_name_FCPICM.ToString();


                    modelo.legalBase[1].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";




                    string baselegal_tax_name_ST = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "ST" && enquadramento.observacaoFiscal != null)
                        {
                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_ST = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;
                        }
                        else
                        {
                            baselegal_tax_name_ST = "Sem observacao legal na regra sovos para imposto ST";
                        }

                    }
                    modelo.legalBase[2].name = baselegal_tax_name_ST.ToString();

                    modelo.legalBase[2].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string baselegal_tax_name_PIS = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "PIS" && enquadramento.observacaoFiscal != null)
                        {


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_PIS = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;


                        }
                        else
                        {
                            baselegal_tax_name_PIS = "Sem observacao legal na regra sovos para imposto PIS";
                        }

                    }
                    modelo.legalBase[3].name = baselegal_tax_name_PIS.ToString();

                    modelo.legalBase[3].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string baselegal_tax_name_COFINS = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "COFINS" && enquadramento.observacaoFiscal != null)
                        {


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_COFINS = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;



                        }
                        else
                        {
                            baselegal_tax_name_COFINS = "Sem observacao legal na regra sovos para imposto COFINS";
                        }

                    }
                    modelo.legalBase[4].name = baselegal_tax_name_COFINS.ToString();

                    modelo.legalBase[4].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";



                    string regra_tax_name_icms = "sem enquadramentos conclusivos na regra Sovos para ICMS";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "ICMS" && enquadramentosConclusivos.status == "Regra aplicada")
                        {


                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_icms = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;
                        }


                    }


                    modelo.legalBase[5].name = regra_tax_name_icms.ToString();

                    modelo.legalBase[5].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string regra_tax_name_FCPICM = "sem enquadramentos conclusivos na regra Sovos para FCPICM";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "FCPICM" && enquadramentosConclusivos.status == "Regra aplicada")
                        {


                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_FCPICM = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;

                        }

                    }

                    modelo.legalBase[6].name = regra_tax_name_FCPICM.ToString();

                    modelo.legalBase[6].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string regra_tax_name_ST = "sem enquadramentos conclusivos na regra Sovos para ST";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "ST" && enquadramentosConclusivos.status == "Regra aplicada")
                        {


                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_ST = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;

                        }

                    }

                    modelo.legalBase[7].name = regra_tax_name_ST.ToString();

                    modelo.legalBase[7].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string regra_tax_name_PIS = "sem enquadramentos conclusivos na regra Sovos para PIS";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "PIS" && enquadramentosConclusivos.status == "Regra aplicada")
                        {


                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_PIS = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;

                        }

                    }

                    modelo.legalBase[8].name = regra_tax_name_PIS.ToString();

                    modelo.legalBase[8].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";



                    string regra_tax_name_COFINS = "sem enquadramentos conclusivos na regra Sovos para COFINS";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "COFINS" && enquadramentosConclusivos.status == "Regra aplicada")
                        {

                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_COFINS = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;

                        }

                    }

                    modelo.legalBase[9].name = regra_tax_name_COFINS.ToString();

                    modelo.legalBase[9].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string regra_tax_name_IPI = "sem enquadramentos conclusivos na regra Sovos para IPI";
                    foreach (dynamic enquadramentosConclusivos in itensDocFiscal.enquadramentosConclusivos)
                    {
                        if (enquadramentosConclusivos.sigla == "IPI" && enquadramentosConclusivos.status == "Regra aplicada")
                        {


                            string descricao = enquadramentosConclusivos.descricao.ToString(CultureInfo.InvariantCulture);
                            regra_tax_name_IPI = descricao.Length > 100 ? descricao.Substring(0, 100) : descricao;
                            break;

                        }

                    }

                    modelo.legalBase[10].name = regra_tax_name_IPI.ToString();

                    modelo.legalBase[10].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";



                    string baselegal_tax_name_II = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "II" && enquadramento.observacaoFiscal != null)
                        {


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_II = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;



                        }
                        else
                        {
                            baselegal_tax_name_II = "Sem observacao legal na regra sovos para imposto II";
                        }

                    }
                    modelo.legalBase[11].name = baselegal_tax_name_II.ToString();

                    modelo.legalBase[11].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";




                    string baselegal_tax_name_DIFAL = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "DIFAL" && enquadramento.observacaoFiscal != null)
                        {


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_DIFAL = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;



                        }
                        else
                        {
                            baselegal_tax_name_DIFAL = "Sem observacao legal na regra sovos para imposto DIFAL";
                        }

                    }
                    modelo.legalBase[12].name = baselegal_tax_name_DIFAL.ToString();

                    modelo.legalBase[12].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";


                    string baselegal_tax_name_FCPDIF = string.Empty;
                    foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                    {
                        if (enquadramento.dsSigla == "FCPDIF" && enquadramento.observacaoFiscal != null)
                        {


                            string observacaoFiscal = enquadramento.observacaoFiscal.ToString();
                            baselegal_tax_name_FCPDIF = observacaoFiscal.Length > 100 ? observacaoFiscal.Substring(0, 100) : observacaoFiscal;
                            break;



                        }
                        else
                        {
                            baselegal_tax_name_FCPDIF = "Sem observacao legal na regra sovos para imposto FCPDIF";
                        }

                    }
                    modelo.legalBase[13].name = baselegal_tax_name_FCPDIF.ToString();

                    modelo.legalBase[13].url = "https://taxrules.taxweb.com.br/accounts/1/tax_laws";



                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()))
                    {
                        modelo.conditions[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.conditions[0]._operator = "equals";
                        modelo.conditions[0].value[0] = firstElement.naturezaOperacao.ToString();
                    }







                    //Rascunho
                    // List<string> numbers = new List<string> { "0", "1", "2", "3", "4", "5", "6", "7", "8" };
                    //string[] value = numbers.Select(n => "\"" + n + "\"").ToArray();





                    if (itensDocFiscal != null)
                    {
                        if (!string.IsNullOrEmpty(itensDocFiscal.cdCSTICMS?.ToString()))
                        {
                            string primeiroCaractere = itensDocFiscal.cdCSTICMS.ToString().Substring(0, 1);

                            if (primeiroCaractere == "1" || primeiroCaractere == "2" || primeiroCaractere == "3" || primeiroCaractere == "8")
                            {
                                modelo.conditions[1].variable = "NFe.infNFe.det.imposto.ICMS.orig";
                                modelo.conditions[1]._operator = "equals";
                                modelo.conditions[1].value = new string[] { "1", "2", "3", "8" };
                            }
                            else if (primeiroCaractere == "0" || primeiroCaractere == "4" || primeiroCaractere == "5" || primeiroCaractere == "6" || primeiroCaractere == "7")
                            {
                                modelo.conditions[1].variable = "NFe.infNFe.det.imposto.ICMS.orig";
                                modelo.conditions[1]._operator = "equals";
                                modelo.conditions[1].value = new string[] { "0", "4", "5", "6", "7" };
                            }
                            else
                            {
                                modelo.conditions[1].variable = "NFe.infNFe.det.imposto.ICMS.orig";
                                modelo.conditions[1]._operator = "equals";
                                modelo.conditions[1].value = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" };
                            }
                        }
                        else
                        {
                            modelo.conditions[1].variable = "NFe.infNFe.det.imposto.ICMS.orig";
                            modelo.conditions[1]._operator = "equals";
                            modelo.conditions[1].value = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" };
                        }
                    }
                    else
                    {
                        // Lógica para tratar o caso em que itensDocFiscal é nulo
                    }










                    string naturezaOperacao = firstElement.naturezaOperacao?.ToString();
                    if (!string.IsNullOrEmpty(naturezaOperacao) && naturezaOperacao == "002")
                    {

                        if (emitente.uf.ToString() == destinatario.uf.ToString())
                        {
                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";
                            modelo.conditions[2].value[0] = emitente.uf.ToString();


                            modelo.conditions[10].variable = "NFe.infNFe.ide.idDest";
                            modelo.conditions[10]._operator = "equals";
                            modelo.conditions[10].value[0] = "1";
                        }
                        else
                        if (destinatario.uf.ToString() == "EX")
                        {
                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";
                            modelo.conditions[2].value[0] = emitente.uf.ToString();

                            modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                            modelo.conditions[3]._operator = "equals";
                            modelo.conditions[3].value[0] = destinatario.uf.ToString();

                            modelo.conditions[10].variable = "NFe.infNFe.ide.idDest";
                            modelo.conditions[10]._operator = "equals";
                            modelo.conditions[10].value[0] = "3";
                        }
                        else
                        {
                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";
                            modelo.conditions[2].value[0] = emitente.uf.ToString();

                            modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                            modelo.conditions[3]._operator = "equals";
                            modelo.conditions[3].value[0] = destinatario.uf.ToString();

                            modelo.conditions[10].variable = "NFe.infNFe.ide.idDest";
                            modelo.conditions[10]._operator = "equals";
                            modelo.conditions[10].value[0] = "2";

                        }



                        if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count == 1 && emitente.regTribDiferenciado[0] == "")
                        {
                            modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                            modelo.conditions[4]._operator = "equals";
                            modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0 && !string.IsNullOrEmpty(naturezaOperacao))
                        {
                            bool encontrouLF = false;

                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if ((valor.ToString() == "LFDES") && (itensDocFiscal.prodItem.NCM.ToString() == "33030010"))
                                {
                                    modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                    modelo.conditions[4]._operator = "equals";
                                    modelo.conditions[4].value = new string[] { "3303*", "3304*", "3305*", "3307*", "34011190", "34012010", "96032100" };

                                    encontrouLF = true;
                                    break;
                                }

                                if ((valor.ToString() == "LFEM" || valor.ToString() == "LFDES") && (firstElement.naturezaOperacao.ToString() == "125"))
                                {
                                    modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                    modelo.conditions[4]._operator = "equals";
                                    modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                                    encontrouLF = true;
                                    break;
                                }
                                else if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                                {
                                    encontrouLF = true;
                                    break;
                                }
                            }

                            if (!encontrouLF)
                            {
                                modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                modelo.conditions[4]._operator = "equals";
                                modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                            }
                        }








                        if (itensDocFiscal.prodItem != null && itensDocFiscal.prodItem.CEST != null && !string.IsNullOrEmpty(itensDocFiscal.prodItem.CEST.ToString()))
                        {
                            modelo.conditions[5].variable = "NFe.infNFe.det.prod.CEST";
                            modelo.conditions[5]._operator = "equals";
                            modelo.conditions[5].value[0] = itensDocFiscal.prodItem.CEST.ToString();
                        }

                        if (itensDocFiscal.prodItem != null && itensDocFiscal.prodItem.exNCM != null && !string.IsNullOrEmpty(itensDocFiscal.prodItem.exNCM.ToString()))
                        {
                            modelo.conditions[6].variable = "NFe.infNFe.det.prod.EXNCM";
                            modelo.conditions[6]._operator = "equals";
                            modelo.conditions[6].value[0] = itensDocFiscal.prodItem.exNCM.ToString();
                        }


                        if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count == 1 && emitente.regTribDiferenciado[0] == "")
                        {
                            // A lista está vazia, não fazemos nada aqui
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0)
                        {


                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if (valor.ToString() == "LFEM")
                                {
                                    modelo.conditions[7].variable = "NFe.infNFe.emit.crtEspecialEstadual";
                                    modelo.conditions[7]._operator = "equals";
                                    modelo.conditions[7].value[0] = "018";
                                    break;
                                }
                                else if (valor.ToString() == "LFDES")
                                {
                                    modelo.conditions[7].variable = "NFe.infNFe.emit.crtEspecialEstadual";
                                    modelo.conditions[7]._operator = "equals";
                                    modelo.conditions[7].value[0] = "017";
                                    break;
                                }
                            }
                        }



                    }
                    else
                    {


                        if (destinatario.regTribDiferenciado != null)
                        {
                            modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                            modelo.conditions[4]._operator = "equals";
                            modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                        }
                        else
                        if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count == 1 && emitente.regTribDiferenciado[0] == "")
                        {
                            modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                            modelo.conditions[4]._operator = "equals";
                            modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0 && !string.IsNullOrEmpty(naturezaOperacao) && (firstElement.naturezaOperacao.ToString() == "013" || firstElement.naturezaOperacao.ToString() == "014" || firstElement.naturezaOperacao.ToString() == "239"))
                        {
                            bool encontrouLF = false;

                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                                {
                                    encontrouLF = true;
                                    break;
                                }
                            }

                            if (!encontrouLF)
                            {
                                modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                modelo.conditions[4]._operator = "equals";
                                modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                            }
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0 && !string.IsNullOrEmpty(naturezaOperacao) && firstElement.naturezaOperacao.ToString() == "125")
                        {
                            bool encontrouLF = false;

                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                                {


                                    modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                    modelo.conditions[4]._operator = "equals";
                                    modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };

                                    encontrouLF = true;
                                    break;
                                }
                            }

                            if (!encontrouLF)
                            {
                                modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                modelo.conditions[4]._operator = "equals";
                                modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                            }
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0 && !string.IsNullOrEmpty(naturezaOperacao) && firstElement.naturezaOperacao.ToString() == "012")
                        {
                            bool encontrouLF = false;

                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if ((valor.ToString() == "LFDES") && (itensDocFiscal.prodItem.NCM.ToString() == "33030010"))
                                {
                                    modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                    modelo.conditions[4]._operator = "equals";
                                    modelo.conditions[4].value = new string[] { "3303*", "3304*", "3305*", "3307*", "34011190", "34012010", "96032100" };

                                    encontrouLF = true;
                                    break;
                                }
                                else if (valor.ToString() == "LFEM" || valor.ToString() == "LFDES")
                                {
                                    encontrouLF = true;
                                    break;
                                }
                            }

                            if (!encontrouLF)
                            {
                                modelo.conditions[4].variable = "NFe.infNFe.det.prod.NCM";
                                modelo.conditions[4]._operator = "equals";
                                modelo.conditions[4].value = new string[] { itensDocFiscal.prodItem.NCM };
                            }
                        }











                        if (itensDocFiscal.prodItem != null && itensDocFiscal.prodItem.CEST != null && !string.IsNullOrEmpty(itensDocFiscal.prodItem.CEST.ToString()))
                        {
                            modelo.conditions[5].variable = "NFe.infNFe.det.prod.CEST";
                            modelo.conditions[5]._operator = "equals";
                            modelo.conditions[5].value[0] = itensDocFiscal.prodItem.CEST.ToString();
                        }


                        if (itensDocFiscal.prodItem != null && itensDocFiscal.prodItem.exNCM != null && !string.IsNullOrEmpty(itensDocFiscal.prodItem.exNCM.ToString()))
                        {
                            modelo.conditions[6].variable = "NFe.infNFe.det.prod.EXNCM";
                            modelo.conditions[6]._operator = "equals";
                            modelo.conditions[6].value[0] = itensDocFiscal.prodItem.exNCM.ToString();
                        }

                        if (destinatario.regTribDiferenciado != null && destinatario.regTribDiferenciado.Count > 0 && firstElement.naturezaOperacao.ToString() == "001")
                        {


                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";
                            modelo.conditions[2].value[0] = emitente.uf.ToString();

                            modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                            modelo.conditions[3]._operator = "equals";
                            modelo.conditions[3].value[0] = destinatario.uf.ToString();



                        }
                        else
                        if (emitente.regTribDiferenciado == null && emitente.regTribDiferenciado[0] == "")
                        {
                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";
                            modelo.conditions[2].value[0] = emitente.uf.ToString();

                            modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                            modelo.conditions[3]._operator = "equals";
                            modelo.conditions[3].value[0] = destinatario.uf.ToString();
                        }
                        else if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0)
                        {


                            modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                            modelo.conditions[2]._operator = "equals";

                            modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                            modelo.conditions[3]._operator = "equals";


                            foreach (var valor in emitente.regTribDiferenciado)
                            {
                                if (valor.ToString() == "LFEM")
                                {
                                    modelo.conditions[7].variable = "NFe.infNFe.emit.crtEspecialEstadual";
                                    modelo.conditions[7]._operator = "equals";
                                    modelo.conditions[7].value[0] = "018";
                                    modelo.conditions[2].value[0] = emitente.uf.ToString();
                                    modelo.conditions[3].value[0] = destinatario.uf.ToString();
                                    break;
                                }
                                else if (valor.ToString() == "LFDES")
                                {
                                    modelo.conditions[7].variable = "NFe.infNFe.emit.crtEspecialEstadual";
                                    modelo.conditions[7]._operator = "equals";
                                    modelo.conditions[7].value[0] = "017";
                                    modelo.conditions[2].value[0] = emitente.uf.ToString();
                                    modelo.conditions[3].value[0] = destinatario.uf.ToString();
                                    break;
                                }

                                modelo.conditions[2].variable = "NFe.infNFe.emit.enderEmit.UF";
                                modelo.conditions[2]._operator = "equals";
                                modelo.conditions[2].value[0] = emitente.uf.ToString();

                                modelo.conditions[3].variable = "NFe.infNFe.dest.enderDest.UF";
                                modelo.conditions[3]._operator = "equals";
                                modelo.conditions[3].value[0] = destinatario.uf.ToString();


                            }
                        }

                    }




                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "001" && emitente != null && emitente.cdAtividadeEconomica.Count > 0)
                    {
                        modelo.conditions[11].variable = "NFe.infNFe.emit.CNAE";
                        modelo.conditions[11]._operator = "equals";
                        modelo.conditions[11].value = new string[emitente.cdAtividadeEconomica.Count];

                        for (int i = 0; i < emitente.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[11].value[i] = emitente.cdAtividadeEconomica[i];
                        }
                    }



                    else
                     if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "069" && emitente != null && emitente.cdAtividadeEconomica.Count > 0)
                    {
                        modelo.conditions[11].variable = "NFe.infNFe.emit.CNAE";
                        modelo.conditions[11]._operator = "equals";
                        modelo.conditions[11].value = new string[emitente.cdAtividadeEconomica.Count];

                        for (int i = 0; i < emitente.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[11].value[i] = emitente.cdAtividadeEconomica[i];
                        }
                    }
                    else
                   if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "005" && destinatario != null && destinatario.cdAtividadeEconomica.Count > 0)
                    {
                        modelo.conditions[11].variable = "NFe.infNFe.dest.CNAE";
                        modelo.conditions[11]._operator = "equals";
                        modelo.conditions[11].value = new string[destinatario.cdAtividadeEconomica.Count];

                        for (int i = 0; i < destinatario.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[11].value[i] = destinatario.cdAtividadeEconomica[i];
                        }
                    }
                    else
                   if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "015" && destinatario != null && destinatario.cdAtividadeEconomica.Count > 0)
                    {
                        modelo.conditions[11].variable = "NFe.infNFe.dest.CNAE";
                        modelo.conditions[11]._operator = "equals";
                        modelo.conditions[11].value = new string[destinatario.cdAtividadeEconomica.Count];

                        for (int i = 0; i < destinatario.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[11].value[i] = destinatario.cdAtividadeEconomica[i];
                        }
                    }
                    else
                   if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "100" && destinatario != null && destinatario.cdAtividadeEconomica.Count > 0)
                    {
                        modelo.conditions[11].variable = "NFe.infNFe.dest.CNAE";
                        modelo.conditions[11]._operator = "equals";
                        modelo.conditions[11].value = new string[destinatario.cdAtividadeEconomica.Count];

                        for (int i = 0; i < destinatario.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[11].value[i] = destinatario.cdAtividadeEconomica[i];
                        }
                    }

                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && (firstElement.naturezaOperacao.ToString() == "014" || firstElement.naturezaOperacao.ToString() == "001" || firstElement.naturezaOperacao.ToString() == "069") && destinatario != null && destinatario.cdAtividadeEconomica.Count > 0 && destinatario.cnpj.ToString() == "27197888007597" && destinatario.uf.ToString() == "SP")
                    {
                        modelo.conditions[16].variable = "NFe.infNFe.dest.CNAE";
                        modelo.conditions[16]._operator = "equals";
                        modelo.conditions[16].value = new string[destinatario.cdAtividadeEconomica.Count];

                        for (int i = 0; i < destinatario.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[16].value[i] = destinatario.cdAtividadeEconomica[i];
                        }
                    }

                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && (firstElement.naturezaOperacao.ToString() == "091") && destinatario != null && destinatario.cnpj.ToString() == "27197888007597" && destinatario.uf.ToString() == "SP")
                    {
                        modelo.conditions[18].variable = "NFe.infNFe.dest.CNPJ";
                        modelo.conditions[18]._operator = "equals";
                        modelo.conditions[18].value = new string[] { destinatario.cnpj.ToString() };

                    }


                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && (firstElement.naturezaOperacao.ToString() == "015" || firstElement.naturezaOperacao.ToString() == "100") && emitente != null && emitente.cdAtividadeEconomica.Count > 0 && emitente.cnpj.ToString() == "27197888007597" && emitente.uf.ToString() == "SP")
                    {
                        modelo.conditions[17].variable = "NFe.infNFe.emit.CNAE";
                        modelo.conditions[17]._operator = "equals";
                        modelo.conditions[17].value = new string[emitente.cdAtividadeEconomica.Count];

                        for (int i = 0; i < emitente.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[17].value[i] = emitente.cdAtividadeEconomica[i];
                        }
                    }


                    if (firstElement.naturezaOperacao.ToString() == "014" && emitente.cnpj.ToString() == "27197888007597" && itensDocFiscal.CDU1?.ToString() == "RJ")
                    {
                        modelo.conditions[12].variable = "NFe.infNFe.det.prod.CDU1";
                        modelo.conditions[12]._operator = "equals";
                        modelo.conditions[12].value = new string[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "TO" };
                    }

                    if (firstElement.naturezaOperacao.ToString() == "014" && emitente.cnpj.ToString() == "27197888007597" && destinatario.uf?.ToString() == "SP")
                    {
                        modelo.conditions[15].variable = "NFe.infNFe.emit.CNAE";
                        modelo.conditions[15]._operator = "equals";
                        modelo.conditions[15].value = new string[emitente.cdAtividadeEconomica.Count];

                        for (int i = 0; i < emitente.cdAtividadeEconomica.Count; i++)
                        {
                            modelo.conditions[15].value[i] = emitente.cdAtividadeEconomica[i];
                        }
                    }


                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "010" && !string.IsNullOrEmpty(itensDocFiscal.vlAliquotaICMSOperacaoAnterior?.ToString()))
                    {

                        modelo.conditions[13].variable = "NFe.infNFe.det.prod.valor_aliquota_icms_operacao_anterior";
                        modelo.conditions[13]._operator = "equals";
                        modelo.conditions[13].value[0] = itensDocFiscal.vlAliquotaICMSOperacaoAnterior.ToString().Replace(",", ".");
                    }
                    else
                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "009" && !string.IsNullOrEmpty(itensDocFiscal.vlAliquotaICMSOperacaoAnterior?.ToString()))
                    {

                        modelo.conditions[13].variable = "NFe.infNFe.det.prod.valor_aliquota_icms_operacao_anterior";
                        modelo.conditions[13]._operator = "equals";
                        modelo.conditions[13].value[0] = itensDocFiscal.vlAliquotaICMSOperacaoAnterior.ToString().Replace(",", ".");
                    }

                    if (firstElement.cdTipo?.ToString() == "E")
                    {
                        modelo.conditions[14].variable = "NFe.infNFe.ide.tpNF";
                        modelo.conditions[14]._operator = "equals";
                        modelo.conditions[14].value[0] = "0";
                    }



                    //modelo.consequences[47].variable = "NFe.infNFe.det.prod.vUnCom";  // --->> Arredondamento casas decimais
                    //modelo.consequences[47].value = "FIXED(NFe.infNFe.det.prod.vUnCom,6)";

                    //modelo.consequences[48].variable = "NFe.infNFe.det.prod.vUnTrib";  // --->> Arredondamento casas decimais
                    //modelo.consequences[48].value = "FIXED(NFe.infNFe.det.prod.vUnTrib,6)";


                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "002")
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "1";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";

                        modelo.consequences[45].variable = "NFe.infNFe.dest.indIEDest";  // --->> Solicitação Ticket ?? [18/07/2023] corrigir problema PDV
                        modelo.consequences[45].value = "EXISTS(NFe.infNFe.dest.CPF):9:null";

                        modelo.consequences[61].variable = "NFe.infNFe.det.prod.vProd";  // --->> Solicitação Ticket ?? [10/01/2024] corrigir problema PDV
                        modelo.consequences[61].value = "(NFe.infNFe.det.prod.qCom*NFe.infNFe.det.prod.vUnCom)";

                    }
                    else
                if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "012")
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "4";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }
                    else
                if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && (firstElement.naturezaOperacao.ToString() == "005" || firstElement.naturezaOperacao.ToString() == "015"))
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "4";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }
                    else
                     if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "091")
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "4";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }
                    else
                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "073")
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "4";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }
                    else
                    if (!string.IsNullOrEmpty(firstElement.naturezaOperacao?.ToString()) && firstElement.naturezaOperacao.ToString() == "100")
                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "4";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }
                    else

                    {
                        modelo.consequences[0].variable = "NFe.infNFe.ide.natOp";
                        modelo.consequences[0].value = "'" + transacao.ToString() + "'";
                        modelo.consequences[1].variable = "NFe.infNFe.ide.finNFe";
                        modelo.consequences[1].value = "1";
                        modelo.consequences[2].variable = "NFe.infNFe.ide.indIntermed";
                        modelo.consequences[2].value = "0";
                    }




                    if (itensDocFiscal != null)
                    {
                        if (!string.IsNullOrEmpty(itensDocFiscal.cdCfop?.ToString()))
                        {
                            modelo.consequences[3].variable = "NFe.infNFe.det.prod.CFOP";
                            modelo.consequences[3].value = itensDocFiscal.cdCfop.ToString();
                        }
                        else
                        {
                            if (itensDocFiscal.CFOPDeduzido != null)
                            {
                                modelo.consequences[3].variable = "NFe.infNFe.det.prod.CFOP";
                                modelo.consequences[3].value = itensDocFiscal.CFOPDeduzido.ToString();
                            }
                            else
                            {
                                // Lógica para tratar o caso em que CFOPDeduzido é nulo
                            }
                        }
                    }
                    else
                    {
                        // Lógica para tratar o caso em que itensDocFiscal é nulo
                    }







                    if (itensDocFiscal["cdCSTIPI"].ToString() == "01" || itensDocFiscal["cdCSTIPI"].ToString() == "02" || itensDocFiscal["cdCSTIPI"].ToString() == "03" || itensDocFiscal["cdCSTIPI"].ToString() == "04" || itensDocFiscal["cdCSTIPI"].ToString() == "05" || itensDocFiscal["cdCSTIPI"].ToString() == "51" || itensDocFiscal["cdCSTIPI"].ToString() == "52" || itensDocFiscal["cdCSTIPI"].ToString() == "53" || itensDocFiscal["cdCSTIPI"].ToString() == "54" || itensDocFiscal["cdCSTIPI"].ToString() == "55")
                    {


                        modelo.consequences[35].variable = "NFe.infNFe.det.imposto.IPI.IPINT.CST";
                        modelo.consequences[35].value = itensDocFiscal.cdCSTIPI.ToString();

                        decimal vlAliquota_II = 0;
                        if (itensDocFiscal.enquadramentos != null)
                        {
                            foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                            {
                                if (enquadramento.dsSigla == "II")
                                {

                                    modelo.consequences[36].variable = "NFe.infNFe.det.imposto.II.vBC";
                                    modelo.consequences[36].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                    vlAliquota_II = enquadramento.vlAliquota;

                                    modelo.consequences[37].variable = "NFe.infNFe.det.imposto.II.vII";
                                    modelo.consequences[37].value = "NFe.infNFe.det.imposto.II.vBC" + "*" + (vlAliquota_II / 100.0M).ToString("0.0000", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                    modelo.consequences[38].variable = "NFe.infNFe.det.imposto.II.vIOF";
                                    modelo.consequences[38].value = "0.00";

                                    modelo.consequences[39].variable = "NFe.infNFe.det.imposto.II.vDespAdu";
                                    modelo.consequences[39].value = "0.00";

                                    vlAliquota_II /= 100.0M;

                                    break;
                                }
                            }
                        }


                        if (itensDocFiscal.cdEnqIPI == null)
                        {
                            modelo.consequences[40].variable = "NFe.infNFe.det.imposto.IPI.cEnq";
                            modelo.consequences[40].value = "999";
                        }
                        else
                        {
                            modelo.consequences[40].variable = "NFe.infNFe.det.imposto.IPI.cEnq";
                            modelo.consequences[40].value = itensDocFiscal.cdEnqIPI.Value.ToString();
                        }



                    }

                    else
                     if (itensDocFiscal["cdCSTIPI"].ToString() == "00" || itensDocFiscal["cdCSTIPI"].ToString() == "49" || itensDocFiscal["cdCSTIPI"].ToString() == "50" || itensDocFiscal["cdCSTIPI"].ToString() == "99")
                    {

                        modelo.consequences[35].variable = "NFe.infNFe.det.imposto.IPI.IPITrib.CST";
                        modelo.consequences[35].value = itensDocFiscal.cdCSTIPI.ToString();


                        modelo.consequences[36].variable = "NFe.infNFe.det.imposto.IPI.IPITrib.vBC";
                        modelo.consequences[36].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))+NFe.infNFe.det.imposto.II.vII";


                        modelo.consequences[37].variable = "NFe.infNFe.det.imposto.IPI.IPITrib.pIPI";
                        decimal vlAliquota_IPI = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "IPI")
                            {
                                vlAliquota_IPI = enquadramento.vlAliquota != null ? enquadramento.vlAliquota : 0;
                                break;
                            }
                        }
                        modelo.consequences[37].value = vlAliquota_IPI.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                        modelo.consequences[38].variable = "NFe.infNFe.det.imposto.IPI.IPITrib.vIPI";
                        modelo.consequences[38].value = "NFe.infNFe.det.imposto.IPI.IPITrib.vBC*NFe.infNFe.det.imposto.IPI.IPITrib.pIPI";

                        if (itensDocFiscal.cdEnqIPI == null)
                        {
                            modelo.consequences[39].variable = "NFe.infNFe.det.imposto.IPI.cEnq";
                            modelo.consequences[39].value = "999";
                        }
                        else
                        {
                            modelo.consequences[39].variable = "NFe.infNFe.det.imposto.IPI.cEnq";
                            modelo.consequences[39].value = itensDocFiscal.cdEnqIPI.Value.ToString();
                        }






                        decimal vlAliquota_II = 0;
                        if (itensDocFiscal.enquadramentos != null)
                        {
                            foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                            {
                                if (enquadramento.dsSigla == "II")
                                {

                                    modelo.consequences[40].variable = "NFe.infNFe.det.imposto.II.vBC";
                                    modelo.consequences[40].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                    vlAliquota_II = enquadramento.vlAliquota;

                                    modelo.consequences[41].variable = "NFe.infNFe.det.imposto.II.vII";
                                    modelo.consequences[41].value = "NFe.infNFe.det.imposto.II.vBC" + "*" + (vlAliquota_II / 100.0M).ToString("0.0000", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                    modelo.consequences[42].variable = "NFe.infNFe.det.imposto.II.vIOF";
                                    modelo.consequences[42].value = "0.00";

                                    modelo.consequences[43].variable = "NFe.infNFe.det.imposto.II.vDespAdu";
                                    modelo.consequences[43].value = "0.00";

                                    vlAliquota_II /= 100.0M;

                                    break;
                                }
                            }
                        }




                    }





                    if (emitente.uf?.ToString() == "BA")
                    {
                        modelo.consequences[44].variable = "NFe.infNFe.autXML.CNPJ";
                        modelo.consequences[44].value = "13937073000156";
                    }






                    if (itensDocFiscal["cdCSTPIS"].ToString() == "04" || itensDocFiscal["cdCSTPIS"].ToString() == "05" || itensDocFiscal["cdCSTPIS"].ToString() == "06" || itensDocFiscal["cdCSTPIS"].ToString() == "07" || itensDocFiscal["cdCSTPIS"].ToString() == "08" || itensDocFiscal["cdCSTPIS"].ToString() == "09")
                    {






                        modelo.consequences[4].variable = "NFe.infNFe.det.imposto.PIS.PISNT.CST";
                        modelo.consequences[4].value = itensDocFiscal.cdCSTPIS.ToString();
                        modelo.consequences[5].variable = "NFe.infNFe.det.imposto.COFINS.COFINSNT.CST";
                        modelo.consequences[5].value = itensDocFiscal.cdCSTCOFINS.ToString();



                    }
                    else
                if (itensDocFiscal["cdCSTPIS"].ToString() == "49" || itensDocFiscal["cdCSTPIS"].ToString() == "50" || itensDocFiscal["cdCSTPIS"].ToString() == "67" || itensDocFiscal["cdCSTPIS"].ToString() == "70" || itensDocFiscal["cdCSTPIS"].ToString() == "72" || itensDocFiscal["cdCSTPIS"].ToString() == "98" || itensDocFiscal["cdCSTPIS"].ToString() == "99" || itensDocFiscal["cdCSTPIS"].ToString() == "71" || itensDocFiscal["cdCSTPIS"].ToString() == "73" || itensDocFiscal["cdCSTPIS"].ToString() == "74")
                    {


                        modelo.consequences[4].variable = "NFe.infNFe.det.imposto.PIS.PISOutr.CST";
                        modelo.consequences[4].value = itensDocFiscal.cdCSTPIS.ToString();
                        modelo.consequences[5].variable = "NFe.infNFe.det.imposto.PIS.PISOutr.vBC";
                        modelo.consequences[5].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                        modelo.consequences[6].variable = "NFe.infNFe.det.imposto.PIS.PISOutr.pPIS";
                        decimal vlAliquota_PIS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "PIS")
                            {
                                vlAliquota_PIS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[6].value = vlAliquota_PIS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[7].variable = "NFe.infNFe.det.imposto.PIS.PISOutr.vPIS";
                        modelo.consequences[7].value = "NFe.infNFe.det.imposto.PIS.PISOutr.vBC*NFe.infNFe.det.imposto.PIS.PISOutr.pPIS";
                        modelo.consequences[8].variable = "NFe.infNFe.det.imposto.COFINS.COFINSOutr.CST";
                        modelo.consequences[8].value = itensDocFiscal.cdCSTCOFINS.ToString();
                        modelo.consequences[9].variable = "NFe.infNFe.det.imposto.COFINS.COFINSOutr.vBC";
                        modelo.consequences[9].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                        modelo.consequences[10].variable = "NFe.infNFe.det.imposto.COFINS.COFINSOutr.pCOFINS";
                        decimal vlAliquota_COFINS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "COFINS")
                            {
                                vlAliquota_COFINS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[10].value = vlAliquota_COFINS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[11].variable = "NFe.infNFe.det.imposto.COFINS.COFINSOutr.vCOFINS";
                        modelo.consequences[11].value = "NFe.infNFe.det.imposto.COFINS.COFINSOutr.vBC*NFe.infNFe.det.imposto.COFINS.COFINSOutr.pCOFINS";





                    }
                    else
                   if (firstElement.naturezaOperacao.ToString() == "001" || firstElement.naturezaOperacao.ToString() == "002") ///--->> Exclusao do ICMS da base de calculo do PIS e da Cofins
                    {
                        modelo.consequences[4].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.CST";
                        modelo.consequences[4].value = itensDocFiscal.cdCSTPIS.ToString();
                        modelo.consequences[5].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.vBC";
                        modelo.consequences[5].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)-(NFe.infNFe.det.imposto.ICMS.ICMS00.vICMS)-(NFe.infNFe.det.imposto.ICMS.ICMS00.vFCP)-(NFe.infNFe.det.imposto.ICMS.ICMS20.vICMS)-(NFe.infNFe.det.imposto.ICMS.ICMS20.vFCP))";
                        modelo.consequences[6].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.pPIS";
                        decimal vlAliquota_PIS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "PIS")
                            {
                                vlAliquota_PIS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[6].value = vlAliquota_PIS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[7].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.vPIS";
                        modelo.consequences[7].value = "NFe.infNFe.det.imposto.PIS.PISAliq.vBC*NFe.infNFe.det.imposto.PIS.PISAliq.pPIS";
                        modelo.consequences[8].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.CST";
                        modelo.consequences[8].value = itensDocFiscal.cdCSTCOFINS.ToString();
                        modelo.consequences[9].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vBC";
                        modelo.consequences[9].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)-(NFe.infNFe.det.imposto.ICMS.ICMS00.vICMS)-(NFe.infNFe.det.imposto.ICMS.ICMS00.vFCP)-(NFe.infNFe.det.imposto.ICMS.ICMS20.vICMS)-(NFe.infNFe.det.imposto.ICMS.ICMS20.vFCP))";
                        modelo.consequences[10].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.pCOFINS";
                        decimal vlAliquota_COFINS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "COFINS")
                            {
                                vlAliquota_COFINS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[10].value = vlAliquota_COFINS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[11].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vCOFINS";
                        modelo.consequences[11].value = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vBC*NFe.infNFe.det.imposto.COFINS.COFINSAliq.pCOFINS";


                    }
                    else
                    {
                        modelo.consequences[4].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.CST";
                        modelo.consequences[4].value = itensDocFiscal.cdCSTPIS.ToString();
                        modelo.consequences[5].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.vBC";
                        modelo.consequences[5].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                        modelo.consequences[6].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.pPIS";
                        decimal vlAliquota_PIS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "PIS")
                            {
                                vlAliquota_PIS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[6].value = vlAliquota_PIS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[7].variable = "NFe.infNFe.det.imposto.PIS.PISAliq.vPIS";
                        modelo.consequences[7].value = "NFe.infNFe.det.imposto.PIS.PISAliq.vBC*NFe.infNFe.det.imposto.PIS.PISAliq.pPIS";
                        modelo.consequences[8].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.CST";
                        modelo.consequences[8].value = itensDocFiscal.cdCSTCOFINS.ToString();
                        modelo.consequences[9].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vBC";
                        modelo.consequences[9].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                        modelo.consequences[10].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.pCOFINS";
                        decimal vlAliquota_COFINS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "COFINS")
                            {
                                vlAliquota_COFINS = enquadramento.vlAliquota;
                                break;
                            }
                        }
                        modelo.consequences[10].value = vlAliquota_COFINS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[11].variable = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vCOFINS";
                        modelo.consequences[11].value = "NFe.infNFe.det.imposto.COFINS.COFINSAliq.vBC*NFe.infNFe.det.imposto.COFINS.COFINSAliq.pCOFINS";


                    }



                    if (emitente.regTribDiferenciado != null && emitente.regTribDiferenciado.Count > 0)
                    {

                        foreach (var valor in emitente.regTribDiferenciado)
                        {


                            if (valor.ToString() == "LFEM")
                            {
                                modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                                modelo.consequences[12].value = "0.00";

                                break;
                            }
                            else
                            if (valor.ToString() == "LFDES")
                            {
                                modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                                modelo.consequences[12].value = "0.00";
                                break;
                            }


                            //Controle para avaliar a necessidade de adicionar novo regTribDiferenciado (crtEspecialEstadual)

                            if (firstElement.naturezaOperacao.ToString() == "002" && valor.ToString() != "LFEM" && valor.ToString() != "LFDES")
                            {
                                modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                                modelo.consequences[12].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*NFe.infNFe.det.prod.pIBPT";
                            }
                            if (firstElement.naturezaOperacao.ToString() != "002" && valor.ToString() != "LFEM" && valor.ToString() != "LFDES")
                            {
                                modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                                modelo.consequences[12].value = "0.00";
                            }


                        }

                    }
                    else
                   if (firstElement.naturezaOperacao.ToString() == "002")
                    {
                        modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                        modelo.consequences[12].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*NFe.infNFe.det.prod.pIBPT";
                    }
                    else
                    {
                        modelo.consequences[12].variable = "NFe.infNFe.det.imposto.vTotTrib";
                        modelo.consequences[12].value = "0.00";
                    }



                    if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "00")
                    {

                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.orig";
                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.CST";
                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.modBC";
                        modelo.consequences[15].value = "3";

                        if (firstElement.naturezaOperacao?.ToString() == "005"||firstElement.naturezaOperacao?.ToString() == "091")
                        {
                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.vBC";
                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))";
                        }
                        else
                        {
                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.vBC";
                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                        }
                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.pICMS";
                        decimal vlAliquota_ICMS = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "ICMS")
                            {
                                if (enquadramento.vlAliquota != null)
                                {
                                    vlAliquota_ICMS = enquadramento.vlAliquota;
                                }
                                break;
                            }
                        }
                        modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                        modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.vICMS";
                        modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.ICMS00.vBC*NFe.infNFe.det.imposto.ICMS.ICMS00.pICMS";





                        decimal vlAliquota_FCPICM = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "FCPICM" && enquadramento.vlAliquota != null)
                            {
                                vlAliquota_FCPICM = enquadramento.vlAliquota;
                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.pFCP";
                                modelo.consequences[19].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS00.vFCP";
                                modelo.consequences[20].value = "NFe.infNFe.det.imposto.ICMS.ICMS00.vBC*NFe.infNFe.det.imposto.ICMS.ICMS00.pFCP";
                                break;
                            }

                        }



                        decimal vlAliquota_DIFAL = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "DIFAL" && enquadramento.vlAliquota != null)
                            {
                                vlAliquota_DIFAL = enquadramento.vlAliquota;
                                modelo.consequences[51].variable = "NFe.infNFe.det.imposto.ICMSUFDest.pICMSUFDest";
                                modelo.consequences[51].value = vlAliquota_DIFAL.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                modelo.consequences[52].variable = "NFe.infNFe.det.imposto.ICMSUFDest.vBCUFDest";
                                modelo.consequences[52].value = "NFe.infNFe.det.imposto.ICMS.ICMS00.vBC";

                                modelo.consequences[53].variable = "NFe.infNFe.det.imposto.ICMSUFDest.vICMSUFDest";
                                modelo.consequences[53].value = "((NFe.infNFe.det.imposto.ICMS.ICMS00.vBC * NFe.infNFe.det.imposto.ICMSUFDest.pICMSUFDest) - NFe.infNFe.det.imposto.ICMS.ICMS00.vICMS) * NFe.infNFe.det.imposto.ICMSUFDest.pICMSInterPart";

                                modelo.consequences[54].variable = "NFe.infNFe.det.imposto.ICMSUFDest.pICMSInter";
                                modelo.consequences[54].value = "NFe.infNFe.det.imposto.ICMS.ICMS00.pICMS";

                                modelo.consequences[55].variable = "NFe.infNFe.det.imposto.ICMSUFDest.pICMSInterPart";
                                modelo.consequences[55].value = itensDocFiscal.percPartUFDestDIFAL.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                modelo.consequences[56].variable = "NFe.infNFe.det.imposto.ICMSUFDest.vICMSUFRemet";
                                modelo.consequences[56].value = "((NFe.infNFe.det.imposto.ICMS.ICMS00.vBC * NFe.infNFe.det.imposto.ICMSUFDest.pICMSUFDest) - NFe.infNFe.det.imposto.ICMS.ICMS00.vICMS) - NFe.infNFe.det.imposto.ICMSUFDest.vICMSUFDest";

                                break;
                            }

                        }




                        decimal vlAliquota_FCPDIF = 0;
                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                        {
                            if (enquadramento.dsSigla == "FCPDIF" && enquadramento.vlAliquota != null)
                            {
                                vlAliquota_FCPDIF = enquadramento.vlAliquota;
                                modelo.consequences[57].variable = "NFe.infNFe.det.imposto.ICMSUFDest.pFCPUFDest";
                                modelo.consequences[57].value = vlAliquota_FCPDIF.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                modelo.consequences[58].variable = "NFe.infNFe.det.imposto.ICMSUFDest.vBCFCPUFDest";
                                modelo.consequences[58].value = "NFe.infNFe.det.imposto.ICMSUFDest.vBCUFDest";

                                modelo.consequences[59].variable = "NFe.infNFe.det.imposto.ICMSUFDest.vFCPUFDest";
                                modelo.consequences[59].value = "(NFe.infNFe.det.imposto.ICMSUFDest.vBCFCPUFDest * NFe.infNFe.det.imposto.ICMSUFDest.pFCPUFDest)";

                                break;
                            }

                        }




                    }
                    else
                    {



                        if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "60")
                        {

                            modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.orig";
                            modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";


                            modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.CST";
                            modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);


                            modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.vBCSTRet";
                            modelo.consequences[15].value = "NFe.infNFe.det.imposto.ICMS.vBCSTRet>0.00:NFe.infNFe.det.imposto.ICMS.vBCSTRet:0.00";
                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.pST";
                            modelo.consequences[16].value = "NFe.infNFe.det.imposto.ICMS.pST>0.00:NFe.infNFe.det.imposto.ICMS.pST:0.00";
                            modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.vICMSSubstituto";
                            modelo.consequences[17].value = "NFe.infNFe.det.imposto.ICMS.vICMSSubstituto>0.00:NFe.infNFe.det.imposto.ICMS.vICMSSubstituto:0.00";
                            modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.vICMSSTRet";
                            modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.vICMSSTRet>0.00:NFe.infNFe.det.imposto.ICMS.vICMSSTRet:0.00";
                            modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.pRedBCEfet";
                            modelo.consequences[19].value = "NFe.infNFe.det.imposto.ICMS.pRedBCEfet>0.00:NFe.infNFe.det.imposto.ICMS.pRedBCEfet:0.00";
                            modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.vBCEfet";
                            modelo.consequences[20].value = "NFe.infNFe.det.imposto.ICMS.vBCEfet>0.00:NFe.infNFe.det.imposto.ICMS.vBCEfet:0.00";
                            modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.pICMSEfet";
                            modelo.consequences[21].value = "NFe.infNFe.det.imposto.ICMS.pICMSEfet>0.00:NFe.infNFe.det.imposto.ICMS.pICMSEfet:0.00";
                            modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS60.vICMSEfet";
                            modelo.consequences[22].value = "NFe.infNFe.det.imposto.ICMS.vICMSEfet>0.00:NFe.infNFe.det.imposto.ICMS.vICMSEfet:0.00";




                            string CBenefs = string.Empty;
                            foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                            {
                                if ((enquadramento.dsSigla == "ST" || enquadramento.dsSigla == "VLBCST") && itensDocFiscal.CBenef != null)
                                {
                                    CBenefs = itensDocFiscal.CBenef;
                                    modelo.consequences[23].variable = "NFe.infNFe.det.prod.cBenef";
                                    modelo.consequences[23].value = "'" + CBenefs + "'";
                                    break;
                                }

                            }






                        }
                        else
                        {
                            if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "20")
                            {

                                modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.orig";
                                modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.CST";
                                modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.modBC";
                                modelo.consequences[15].value = "3";

                                if (firstElement.naturezaOperacao?.ToString() == "005")
                                {
                                    modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBC";
                                    modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS20.pRedBC)";
                                }
                                else
                                {
                                    modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBC";
                                    modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS20.pRedBC)";
                                }
                                modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.pICMS";
                                decimal vlAliquota_ICMS = 0;
                                foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                {
                                    if (enquadramento.dsSigla == "ICMS")
                                    {
                                        vlAliquota_ICMS = enquadramento.vlAliquota;
                                        break;
                                    }
                                }
                                modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vICMS";
                                modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBC*NFe.infNFe.det.imposto.ICMS.ICMS20.pICMS";
                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.pRedBC";
                                decimal percReducaoBase_ICMS = 0;
                                foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                {
                                    if (enquadramento.dsSigla == "ICMS" && enquadramento.percReducaoBase != null)
                                    {
                                        percReducaoBase_ICMS = enquadramento.percReducaoBase ?? 0;
                                        break;
                                    }
                                }
                                modelo.consequences[19].value = modelo.consequences[19].value = percReducaoBase_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                string CBenefs = string.Empty;
                                foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                {
                                    if (enquadramento.dsSigla == "ICMS" && itensDocFiscal.CBenef != null)
                                    {
                                        CBenefs = itensDocFiscal.CBenef;
                                        modelo.consequences[20].variable = "NFe.infNFe.det.prod.cBenef";
                                        modelo.consequences[20].value = "'" + CBenefs + "'";
                                        break;
                                    }

                                }




                                modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.motDesICMS";
                                modelo.consequences[21].value = "9";


                                if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                {
                                    modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vICMSDeson";
                                    decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                    CultureInfo culture = new CultureInfo("en-US");
                                    string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);
                                    modelo.consequences[22].value = "(" + aliquotaICMSDesoneradoString + "*NFe.infNFe.det.imposto.ICMS.ICMS20.vBC)";



                                }
                                else
                                if (emitente.uf?.ToString() == "DF" && (firstElement.naturezaOperacao.ToString() == "002" || firstElement.naturezaOperacao.ToString() == "012"))
                                {
                                    modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vICMSDeson";
                                    modelo.consequences[22].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)) * NFe.infNFe.det.imposto.ICMS.ICMS20.pICMSDeson";


                                    modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.pICMSDeson";
                                    modelo.consequences[60].value = "18.00";
                                }
                                else
                                {

                                    modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vICMSDeson";   //--> atendimento ao problema do desconto que zera a base de calculo do item, operador "NFe.infNFe.det.prod.vDesc<0.03:"
                                    modelo.consequences[22].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-(NFe.infNFe.det.imposto.ICMS.ICMS20.pICMS*(1-NFe.infNFe.det.imposto.ICMS.ICMS20.pRedBC)))/(1-NFe.infNFe.det.imposto.ICMS.ICMS20.pICMS)-((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                                }





                                decimal vlAliquota_FCPICM = 0;
                                foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                {
                                    if (enquadramento.dsSigla == "FCPICM" && vlAliquota_FCPICM != null)
                                    {

                                        vlAliquota_FCPICM = enquadramento.vlAliquota;
                                        modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBCFCP";
                                        modelo.consequences[23].value = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBC";

                                        modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.pFCP";
                                        modelo.consequences[24].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                        modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS20.vFCP";
                                        modelo.consequences[25].value = "NFe.infNFe.det.imposto.ICMS.ICMS20.vBCFCP*NFe.infNFe.det.imposto.ICMS.ICMS20.pFCP";
                                        break;
                                    }

                                }


                            }
                            else
                            {
                                if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "40")
                                {

                                    modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.orig";
                                    modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                    modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.CST";
                                    modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);

                                    if (itensDocFiscal != null && itensDocFiscal.CBenef != null)
                                    {
                                        modelo.consequences[15].variable = "NFe.infNFe.det.prod.cBenef";
                                        modelo.consequences[15].value = "'" + itensDocFiscal.CBenef.ToString() + "'";
                                    }


                                    modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.motDesICMS";
                                    modelo.consequences[16].value = "9";


                                    if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                    {
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                        decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                        CultureInfo culture = new CultureInfo("en-US");
                                        string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);  //// Regra especifica aplicada: Definir valor de 0.01 centavo no valor do ICMS desonerao quando o valor do produto for zero. Regra vigente até dia 13/11/2023, após essa data falar com o Marco
                                        modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:(" + aliquotaICMSDesoneradoString + "*(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                        modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                        modelo.consequences[60].value = aliquotaICMSDesoneradoDecimal.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                    }
                                    else
                                    if (emitente.uf?.ToString() == "DF" && (firstElement.naturezaOperacao.ToString() == "002" || firstElement.naturezaOperacao.ToString() == "012"))
                                    {
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                        modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)) * NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";


                                        modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                        modelo.consequences[60].value = "18.00";
                                    }
                                    else
                                    {
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                        modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))"; ///  * NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";


                                        /// modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                        /// modelo.consequences[60].value = "18.00";



                                    }


                                }
                                else
                                {
                                    if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "41")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        if (itensDocFiscal != null && itensDocFiscal.CBenef != null)
                                        {
                                            modelo.consequences[15].variable = "NFe.infNFe.det.prod.cBenef";
                                            modelo.consequences[15].value = "'" + itensDocFiscal.CBenef.ToString() + "'";
                                        }


                                        modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.motDesICMS";
                                        modelo.consequences[16].value = "9";


                                        if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                        {
                                            modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                            decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                            CultureInfo culture = new CultureInfo("en-US");
                                            string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);
                                            modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:(" + aliquotaICMSDesoneradoString + "*(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                            modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                            modelo.consequences[60].value = aliquotaICMSDesoneradoDecimal.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                        }
                                        else
                                        if (emitente.uf?.ToString() == "DF" && (firstElement.naturezaOperacao.ToString() == "002" || firstElement.naturezaOperacao.ToString() == "012"))
                                        {
                                            modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                            modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)) * NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";


                                            modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                            modelo.consequences[60].value = "18.00";
                                        }
                                        else
                                        {
                                            modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.vICMSDeson";
                                            modelo.consequences[17].value = "(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)<0.03:0.01:((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))"; ///*NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";

                                                                                                                                                                                                                                                                                        /// modelo.consequences[60].variable = "NFe.infNFe.det.imposto.ICMS.ICMS40.pICMSDeson";
                                                                                                                                                                                                                                                                                        ///modelo.consequences[60].value = "18.00";


                                        }

                                    }
                                    else
                                         if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "10")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.modBC";
                                        modelo.consequences[15].value = "3";

                                        if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                        {
                                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBC";
                                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBC)";
                                        }
                                        else
                                        {
                                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBC"; ;
                                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBC)";
                                        }
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pICMS";
                                        decimal vlAliquota_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS")
                                            {
                                                vlAliquota_ICMS = enquadramento.vlAliquota;
                                                break;
                                            }
                                        }
                                        modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));




                                        modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMS";
                                        modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBC*NFe.infNFe.det.imposto.ICMS.ICMS10.pICMS";







                                        decimal vlAliquota_FCPICM = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "FCPICM" && enquadramento.vlAliquota != null)
                                            {
                                                vlAliquota_FCPICM = enquadramento.vlAliquota;
                                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pFCP";
                                                modelo.consequences[19].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                                modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP";
                                                modelo.consequences[20].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCP";
                                                modelo.consequences[30].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCP";
                                                modelo.consequences[30].value = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBC";
                                                break;
                                            }

                                        }





                                        modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.modBCST";

                                        decimal modBCST = 0;
                                        decimal pMVAST = 0;
                                        decimal vPauta = 0;
                                        decimal pRedBCST = 0;
                                        decimal pICMSST = 0;
                                        decimal vBCST = 0;

                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            bool isST = enquadramento.dsSigla == "ST";
                                            bool isVLBCST = enquadramento.dsSigla == "VLBCST";
                                            bool hasPercentualMVA = enquadramento.vlPercentualMVA != null;
                                            bool hasPrecoControlado = enquadramento.vlPrecoControlado != null;

                                            modBCST = isST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isVLBCST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : isVLBCST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : 6;

                                            pMVAST = enquadramento.vlPercentualMVA ?? 0;
                                            pRedBCST = enquadramento.percReducaoBase ?? 0;
                                            pICMSST = enquadramento.vlAliquota ?? 0;
                                            vBCST = enquadramento.vlPrecoControlado ?? 0;

                                            if (modBCST != 6)
                                            {
                                                break;
                                            }
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modBCST.ToString();
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            modelo.consequences[21].value = itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modelo.consequences[21].value = modBCST.ToString();
                                        }

                                        if (modBCST == 4)
                                        {
                                            modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pMVAST";
                                            modelo.consequences[22].value = pMVAST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        }
                                        else
                                        { ///não faz nada
                                        }

                                        modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST";
                                        modelo.consequences[23].value = pRedBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                        if ((vBCST > 0) && (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091"))
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST";
                                            modelo.consequences[24].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST)";
                                        }
                                        else
                                        if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST";
                                            modelo.consequences[24].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS10.pMVAST)";

                                        }
                                        else
                                        if (modBCST == 6)
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST";
                                            modelo.consequences[24].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                                        }
                                        else
                                        if (vBCST > 0)
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST";
                                            modelo.consequences[24].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST)";
                                        }
                                        else
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST";
                                            modelo.consequences[24].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS10.pMVAST)";
                                        }



                                        modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pICMSST";
                                        modelo.consequences[25].value = pICMSST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                        if (modBCST == 6)
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMSST";
                                            modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS10.pICMSST)";
                                        }
                                        if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMSST";
                                            modelo.consequences[26].value = "0.00";
                                        }
                                        else
                                        if (firstElement.naturezaOperacao?.ToString() == "091")
                                        {

                                            modelo.consequences[46].variable = "NFe.infNFe.det.prod.vOutro";
                                            modelo.consequences[46].value = "((NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS10.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vICMS)+((NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP)";


                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMSST";
                                            modelo.consequences[26].value = "0.00";

                                        }
                                        else
                                        if ((((pICMSST / 100) * (1 + pMVAST / 100)) * (1 - pRedBCST / 100)) <= 0)
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMSST";
                                            modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS10.pICMSST)";
                                        }
                                        else
                                        {

                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vICMSST";
                                            modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS10.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vICMS";
                                        }









                                        decimal pFCPST = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "FCPST" && enquadramento.vlAliquota != null)
                                            {
                                                pFCPST = enquadramento.vlAliquota;
                                                if ((vBCST > 0) && (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091"))
                                                {
                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST";
                                                    modelo.consequences[27].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete)*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST)";

                                                    modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                    if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "0.00";
                                                    }
                                                    else
                                                    if (firstElement.naturezaOperacao?.ToString() == "091")
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "0.00";

                                                    }
                                                    else
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP";
                                                    }

                                                }
                                                else

                                                if (vBCST > 0)
                                                {
                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST";
                                                    modelo.consequences[27].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete + NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST)";

                                                    modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                    modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                    modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP";


                                                }
                                                else
                                                 if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                                {
                                                   
                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST";
                                                    modelo.consequences[27].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS10.pMVAST)";

                                                    modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                    if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "0.00";
                                                    }
                                                    else
                                                    if (firstElement.naturezaOperacao?.ToString() == "091")
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "0.00";

                                                    }
                                                    else
                                                    {
                                                        modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                        modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP";
                                                    }
                                                }
                                                else
                                                {
                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST";
                                                    modelo.consequences[27].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS10.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS10.pMVAST)";

                                                    modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                    modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS10.vFCPST";
                                                    modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS10.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS10.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS10.vFCP";


                                                }


                                                break;
                                            }

                                        }


                                    }
                                    else
                                      if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "70")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.modBC";
                                        modelo.consequences[15].value = "3";
                                        if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                        {
                                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBC";
                                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBC)";
                                        }
                                        else
                                        {
                                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBC";
                                            modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg)+NFe.infNFe.det.prod.vOutro)*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBC)";

                                        }
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pICMS";
                                        decimal vlAliquota_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS")
                                            {
                                                vlAliquota_ICMS = enquadramento.vlAliquota;
                                                break;
                                            }
                                        }
                                        modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMS";
                                        modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBC*NFe.infNFe.det.imposto.ICMS.ICMS70.pICMS";





                                        decimal vlAliquota_FCPICM = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "FCPICM" && enquadramento.vlAliquota != null)
                                            {
                                                vlAliquota_FCPICM = enquadramento.vlAliquota;
                                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pFCP";
                                                modelo.consequences[19].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                                modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP";
                                                modelo.consequences[20].value = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBC*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCP";
                                                modelo.consequences[34].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCP";
                                                modelo.consequences[34].value = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBC";

                                                break;
                                            }

                                        }




                                        modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.modBCST";

                                        decimal modBCST = 0;
                                        decimal pMVAST = 0;
                                        decimal vPauta = 0;
                                        decimal pRedBCST = 0;
                                        decimal pICMSST = 0;
                                        decimal vBCST = 0;

                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            bool isST = enquadramento.dsSigla == "ST";
                                            bool isVLBCST = enquadramento.dsSigla == "VLBCST";
                                            bool hasPercentualMVA = enquadramento.vlPercentualMVA != null;
                                            bool hasPrecoControlado = enquadramento.vlPrecoControlado != null;

                                            modBCST = isST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isVLBCST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : isVLBCST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : 6;

                                            pMVAST = enquadramento.vlPercentualMVA ?? 0;
                                            pRedBCST = enquadramento.percReducaoBase ?? 0;
                                            pICMSST = enquadramento.vlAliquota ?? 0;
                                            vBCST = enquadramento.vlPrecoControlado ?? 0;

                                            if (modBCST != 6)
                                            {
                                                break;
                                            }
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modBCST.ToString();
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            modelo.consequences[21].value = itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modelo.consequences[21].value = modBCST.ToString();
                                        }

                                        if (modBCST == 4)
                                        {
                                            modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pMVAST";
                                            modelo.consequences[22].value = pMVAST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        }
                                        else
                                        {
                                            //nao faz nada
                                        }

                                        modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST";
                                        modelo.consequences[23].value = pRedBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                        if ((vBCST > 0) && (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091"))
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST";
                                            modelo.consequences[24].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST)";

                                        }
                                        else
                                            if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST";
                                            modelo.consequences[24].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS70.pMVAST)";
                                        }
                                        else
                                           if (vBCST > 0)
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST";
                                            modelo.consequences[24].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST)";
                                        }
                                        else
                                        if (modBCST == 6)
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST";
                                            modelo.consequences[24].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBC)";
                                        }
                                        else
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST";
                                            modelo.consequences[24].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS70.pMVAST)";
                                        }



                                        modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pICMSST";
                                        modelo.consequences[25].value = pICMSST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));




                                        if (firstElement.naturezaOperacao?.ToString() == "091")
                                        {

                                            modelo.consequences[46].variable = "NFe.infNFe.det.prod.vOutro";
                                            modelo.consequences[46].value = "((NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS70.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vICMS)+((NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP)";


                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSST";
                                            modelo.consequences[26].value = "0.00";

                                        }
                                        else
                                        if (modBCST == 6)
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSST";
                                            modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS70.pICMSST)";

                                        }
                                        if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSST";
                                            modelo.consequences[26].value = "0.00";
                                        }
                                        else
                                        {
                                            modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSST";
                                            modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS70.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vICMS";
                                        }







                                        decimal pFCPST = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)                                                                                    
                                        {
                                                    if (enquadramento.dsSigla == "FCPST" && enquadramento.vlAliquota != null)
                                                    {
                                                        pFCPST = enquadramento.vlAliquota;
                                                        if ((vBCST > 0) && (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091"))
                                                        {
                                                            modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST";
                                                            modelo.consequences[27].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete)*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST)";

                                                            modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST";
                                                            modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                            if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "0.00";
                                                            }
                                                            else
                                                            if (firstElement.naturezaOperacao?.ToString() == "091")
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "0.00";

                                                            }
                                                            else
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP";
                                                            }

                                                        }
                                                        else

                                                        if (vBCST > 0)
                                                        {
                                                            modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST";
                                                            modelo.consequences[27].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete + NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST)";

                                                            modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST";
                                                            modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                            modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                            modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP";


                                                        }
                                                        else
                                                         if (firstElement.naturezaOperacao?.ToString() == "005" || firstElement.naturezaOperacao?.ToString() == "091")
                                                        {

                                                            modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST";
                                                            modelo.consequences[27].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS70.pMVAST)";

                                                            modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST";
                                                            modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                            if (firstElement.naturezaOperacao?.ToString() == "005" && emitente.cnpj.ToString() == "27197888007597")
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "0.00";
                                                            }
                                                            else
                                                            if (firstElement.naturezaOperacao?.ToString() == "091")
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "0.00";

                                                            }
                                                            else
                                                            {
                                                                modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                                modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST";
                                                            modelo.consequences[27].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS70.pMVAST)";

                                                            modelo.consequences[28].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST";
                                                            modelo.consequences[28].value = pFCPST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                                            modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vFCPST";
                                                            modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS70.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS70.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS70.vFCP";

                                                        }

                                                        break;
                                                    }

                                        }                                                                                        

                                        



                                        modelo.consequences[30].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.motDesICMS";
                                        modelo.consequences[30].value = "9";


                                        if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                        {
                                            modelo.consequences[31].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSDeson";
                                            decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                            CultureInfo culture = new CultureInfo("en-US");
                                            string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);
                                            modelo.consequences[31].value = "(" + aliquotaICMSDesoneradoString + "*(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                        }
                                        else
                                        {
                                            modelo.consequences[31].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.vICMSDeson";
                                            modelo.consequences[31].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)))";

                                        }


                                        modelo.consequences[32].variable = "NFe.infNFe.det.imposto.ICMS.ICMS70.pRedBC";
                                        decimal percReducaoBase_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && enquadramento.percReducaoBase != null)
                                            {
                                                percReducaoBase_ICMS = enquadramento.percReducaoBase ?? 0;
                                                break;
                                            }
                                        }
                                        modelo.consequences[32].value = modelo.consequences[32].value = percReducaoBase_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                        string CBenefs = string.Empty;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && itensDocFiscal.CBenef != null)
                                            {
                                                CBenefs = itensDocFiscal.CBenef;
                                                modelo.consequences[33].variable = "NFe.infNFe.det.prod.cBenef";
                                                modelo.consequences[33].value = "'" + CBenefs + "'";
                                                break;
                                            }

                                        }





                                    }
                                    else
                                     if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "30")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.modBCST";

                                        decimal modBCST = 0;
                                        decimal pMVAST = 0;
                                        decimal vPauta = 0;
                                        decimal pRedBCST = 0;
                                        decimal pICMSST = 0;
                                        decimal vBCST = 0;

                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            bool isST = enquadramento.dsSigla == "ST";
                                            bool isVLBCST = enquadramento.dsSigla == "VLBCST";
                                            bool hasPercentualMVA = enquadramento.vlPercentualMVA != null;
                                            bool hasPrecoControlado = enquadramento.vlPrecoControlado != null;

                                            modBCST = isST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isVLBCST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : isVLBCST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : 6;

                                            pMVAST = enquadramento.vlPercentualMVA ?? 0;
                                            pRedBCST = enquadramento.percReducaoBase ?? 0;
                                            pICMSST = enquadramento.vlAliquota ?? 0;
                                            vBCST = enquadramento.vlPrecoControlado ?? 0;

                                            if (modBCST != 6)
                                            {
                                                break;
                                            }
                                        }

                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modBCST.ToString();
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            modelo.consequences[15].value = itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modelo.consequences[15].value = modBCST.ToString();
                                        }

                                        if (modBCST == 4)
                                        {
                                            modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.pMVAST";
                                            modelo.consequences[16].value = pMVAST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        }
                                        else
                                        { //não faz nada
                                        }

                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST";
                                        modelo.consequences[17].value = pRedBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                        if (vBCST > 0)
                                        {
                                            modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vBCST";
                                            modelo.consequences[18].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST)";
                                        }
                                        if (modBCST != 6)
                                        {
                                            modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vBCST";
                                            modelo.consequences[18].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg))*(1-NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST)";
                                        }
                                        else
                                        {
                                            modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vBCST";
                                            modelo.consequences[18].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS30.pMVAST)";
                                        }

                                        modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.pICMSST";
                                        modelo.consequences[19].value = pICMSST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                        if (modBCST != 6)
                                        {
                                            modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vICMSST";
                                            modelo.consequences[20].value = "(NFe.infNFe.det.imposto.ICMS.ICMS30.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS30.pICMSST)";

                                        }
                                        else
                                        {

                                            modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vICMSST";
                                            modelo.consequences[20].value = "(NFe.infNFe.det.imposto.ICMS.ICMS30.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS30.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS30.vICMS";

                                        }





                                        decimal pFCPST = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {

                                            if (enquadramento.dsSigla == "FCPST" && pFCPST > 0)
                                            {

                                                pFCPST = enquadramento.vlAliquota;
                                                if (vBCST > 0)
                                                {
                                                    modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vBCFCPST";
                                                    modelo.consequences[21].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST)";

                                                    modelo.consequences[22].value = "NFe.infNFe.det.imposto.ICMS.ICMS30.pFCPST";
                                                    modelo.consequences[22].value = pFCPST.ToString();

                                                    modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vFCPST";
                                                    modelo.consequences[23].value = "(NFe.infNFe.det.imposto.ICMS.ICMS30.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS30.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS30.vFCP";
                                                }
                                                else
                                                {
                                                    modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vBCFCPST";
                                                    modelo.consequences[21].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS30.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS30.pMVAST)";

                                                    modelo.consequences[22].value = "NFe.infNFe.det.imposto.ICMS.ICMS30.pFCPST";
                                                    modelo.consequences[22].value = pFCPST.ToString();

                                                    modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vFCPST";
                                                    modelo.consequences[23].value = "(NFe.infNFe.det.imposto.ICMS.ICMS30.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS30.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS30.vFCP";

                                                }

                                                break;
                                            }



                                        }


                                        modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.motDesICMS";
                                        modelo.consequences[24].value = "9";


                                        if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                        {
                                            modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vICMSDeson";
                                            decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                            CultureInfo culture = new CultureInfo("en-US");
                                            string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);
                                            modelo.consequences[25].value = "(" + aliquotaICMSDesoneradoString + "*(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                        }
                                        else
                                        {
                                            modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS30.vICMSDeson";
                                            modelo.consequences[25].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)))";

                                        }





                                        string CBenefs = string.Empty;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && itensDocFiscal.CBenef != null)
                                            {
                                                CBenefs = itensDocFiscal.CBenef;
                                                modelo.consequences[26].variable = "NFe.infNFe.det.prod.cBenef";
                                                modelo.consequences[26].value = "'" + CBenefs + "'";
                                                break;
                                            }

                                        }





                                    }
                                    else
                                    if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "90")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.modBC";
                                        modelo.consequences[15].value = "3";
                                        modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBC";
                                        modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pICMS";
                                        decimal vlAliquota_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS")
                                            {
                                                vlAliquota_ICMS = enquadramento.vlAliquota;
                                                break;
                                            }
                                        }
                                        modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vICMS";
                                        modelo.consequences[18].value = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBC*NFe.infNFe.det.imposto.ICMS.ICMS90.pICMS";





                                        decimal vlAliquota_FCPICM = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "FCPICM" && enquadramento.vlAliquota != null)
                                            {
                                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pFCP";
                                                vlAliquota_FCPICM = enquadramento.vlAliquota;
                                                modelo.consequences[19].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                                modelo.consequences[34].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCP";
                                                modelo.consequences[34].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";


                                                modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vFCP";
                                                modelo.consequences[20].value = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCP*NFe.infNFe.det.imposto.ICMS.ICMS90.pFCP";



                                                break;
                                            }


                                        }


                                        modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.modBCST";

                                        decimal modBCST = 0;
                                        decimal pMVAST = 0;
                                        decimal vPauta = 0;
                                        decimal pRedBCST = 0;
                                        decimal pICMSST = 0;
                                        decimal vBCST = 0;

                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            bool isST = enquadramento.dsSigla == "ST";
                                            bool isVLBCST = enquadramento.dsSigla == "VLBCST";
                                            bool hasPercentualMVA = enquadramento.vlPercentualMVA != null;
                                            bool hasPrecoControlado = enquadramento.vlPrecoControlado != null;

                                            modBCST = isST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isVLBCST && hasPercentualMVA && !hasPrecoControlado ? 4
                                                      : isST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : isVLBCST && !hasPercentualMVA && hasPrecoControlado ? 5
                                                      : 6;

                                            pMVAST = enquadramento.vlPercentualMVA ?? 0;
                                            pRedBCST = enquadramento.percReducaoBase ?? 0;
                                            pICMSST = enquadramento.vlAliquota ?? 0;
                                            vBCST = enquadramento.vlPrecoControlado ?? 0;

                                            if (modBCST != 6)
                                            {
                                                break;
                                            }
                                        }

                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modBCST.ToString();
                                        }


                                        if (itensDocFiscal.indBaseSTMed != null)
                                        {
                                            modelo.consequences[21].value = itensDocFiscal.indBaseSTMed.ToString();
                                        }
                                        else
                                        {
                                            modelo.consequences[21].value = modBCST.ToString();
                                        }

                                        if (modBCST == 4)
                                        {
                                            modelo.consequences[22].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pMVAST";
                                            modelo.consequences[22].value = pMVAST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        }
                                        else
                                        {
                                            //não faz nada
                                        }
                                        modelo.consequences[23].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBCST";
                                        modelo.consequences[23].value = pRedBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));

                                        if (vBCST > 0)
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCST";
                                            modelo.consequences[24].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBCST)";
                                        }
                                        else
                                        {
                                            modelo.consequences[24].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCST";
                                            modelo.consequences[24].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS90.pMVAST)";
                                        }

                                        modelo.consequences[25].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pICMSST";
                                        modelo.consequences[25].value = pICMSST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {

                                            if (enquadramento.dsSigla == "ST")
                                            {

                                                pICMSST = enquadramento.vlAliquota;

                                                if (pICMSST > 0)
                                                {

                                                    modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vICMSST";
                                                    modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS90.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS90.pICMSST)-NFe.infNFe.det.imposto.ICMS.ICMS90.vICMS";
                                                }
                                            }

                                            else
                                            {
                                                modelo.consequences[26].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vICMSST";
                                                modelo.consequences[26].value = "(NFe.infNFe.det.imposto.ICMS.ICMS90.vBCST*NFe.infNFe.det.imposto.ICMS.ICMS90.pICMSST)";
                                            }

                                        }





                                        decimal pFCPST = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {

                                            if (enquadramento.dsSigla == "FCPST")
                                            {

                                                pFCPST = enquadramento.vlAliquota;

                                                if (vBCST > 0)
                                                {
                                                    modelo.consequences[28].value = "NFe.infNFe.det.imposto.ICMS.ICMS90.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString();

                                                    modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vFCPST";
                                                    modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS90.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS90.vFCP";

                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCPST";
                                                    modelo.consequences[27].value = "(((" + vBCST.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US")) + "*NFe.infNFe.det.prod.qTrib)-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBCST)";
                                                }
                                                else
                                                {

                                                    modelo.consequences[28].value = "NFe.infNFe.det.imposto.ICMS.ICMS90.pFCPST";
                                                    modelo.consequences[28].value = pFCPST.ToString();

                                                    modelo.consequences[29].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vFCPST";
                                                    modelo.consequences[29].value = "(NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCPST*NFe.infNFe.det.imposto.ICMS.ICMS90.pFCPST)-NFe.infNFe.det.imposto.ICMS.ICMS90.vFCP";

                                                    modelo.consequences[27].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vBCFCPST";
                                                    modelo.consequences[27].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))*(1-NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBCST))*(1+NFe.infNFe.det.imposto.ICMS.ICMS90.pMVAST)";
                                                }

                                                break;
                                            }

                                        }


                                        modelo.consequences[30].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.motDesICMS";
                                        modelo.consequences[30].value = "9";


                                        if (itensDocFiscal != null && itensDocFiscal.aliquotaICMSDesonerado != null)
                                        {
                                            modelo.consequences[31].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vICMSDeson";
                                            decimal aliquotaICMSDesoneradoDecimal = itensDocFiscal["aliquotaICMSDesonerado"] / 100.00M;
                                            CultureInfo culture = new CultureInfo("en-US");
                                            string aliquotaICMSDesoneradoString = aliquotaICMSDesoneradoDecimal.ToString("N2", culture);
                                            modelo.consequences[31].value = "(" + aliquotaICMSDesoneradoString + "*(NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";

                                        }
                                        else
                                        {
                                            modelo.consequences[31].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.vICMSDeson";
                                            modelo.consequences[31].value = "(((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro)))";

                                        }


                                        modelo.consequences[32].variable = "NFe.infNFe.det.imposto.ICMS.ICMS90.pRedBC";
                                        decimal percReducaoBase_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && enquadramento.percReducaoBase != null)
                                            {
                                                percReducaoBase_ICMS = enquadramento.percReducaoBase ?? 0;
                                                break;
                                            }
                                        }
                                        modelo.consequences[32].value = modelo.consequences[32].value = percReducaoBase_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));



                                        string CBenefs = string.Empty;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && itensDocFiscal.CBenef != null)
                                            {
                                                CBenefs = itensDocFiscal.CBenef;
                                                modelo.consequences[33].variable = "NFe.infNFe.det.prod.cBenef";
                                                modelo.consequences[33].value = "'" + CBenefs + "'";
                                                break;
                                            }

                                        }





                                    }
                                    else
                                    if (itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2) == "51")
                                    {

                                        modelo.consequences[13].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.orig";
                                        modelo.consequences[13].value = "NFe.infNFe.det.imposto.ICMS.orig";
                                        modelo.consequences[14].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.CST";
                                        modelo.consequences[14].value = itensDocFiscal.cdCSTICMS.ToString().Substring(itensDocFiscal.cdCSTICMS.ToString().Length - 2);
                                        modelo.consequences[15].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.modBC";
                                        modelo.consequences[15].value = "3";
                                        modelo.consequences[16].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.vBC";
                                        modelo.consequences[16].value = "((NFe.infNFe.det.prod.vProd-NFe.infNFe.det.prod.vDesc)+(NFe.infNFe.det.prod.vFrete+NFe.infNFe.det.prod.vSeg+NFe.infNFe.det.prod.vOutro))";
                                        modelo.consequences[17].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.pICMS";
                                        decimal vlAliquota_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS")
                                            {
                                                vlAliquota_ICMS = enquadramento.vlAliquota;
                                                break;
                                            }
                                        }
                                        modelo.consequences[17].value = vlAliquota_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                        modelo.consequences[18].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.vICMS";
                                        modelo.consequences[18].value = "(NFe.infNFe.det.imposto.ICMS.ICMS51.vICMSOp - NFe.infNFe.det.imposto.ICMS.ICMS51.vICMSDif)";

                                        modelo.consequences[47].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.vICMSOp";
                                        modelo.consequences[47].value = "(NFe.infNFe.det.imposto.ICMS.ICMS51.vBC*NFe.infNFe.det.imposto.ICMS.ICMS51.pICMS)";


                                        string CBenefs = string.Empty;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && itensDocFiscal.CBenef != null)
                                            {
                                                CBenefs = itensDocFiscal.CBenef;
                                                modelo.consequences[62].variable = "NFe.infNFe.det.prod.cBenef";
                                                modelo.consequences[62].value = "'" + CBenefs + "'";
                                                break;
                                            }

                                        }


                                        decimal vlAliquota_FCPICM = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "FCPICM" && enquadramento.vlAliquota != null)
                                            {
                                                vlAliquota_FCPICM = enquadramento.vlAliquota;
                                                modelo.consequences[19].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.pFCP";
                                                modelo.consequences[19].value = vlAliquota_FCPICM.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));
                                                modelo.consequences[20].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.vFCP";
                                                modelo.consequences[20].value = "NFe.infNFe.det.imposto.ICMS.ICMS51.vBC*NFe.infNFe.det.imposto.ICMS.ICMS51.pFCP";
                                                break;
                                            }


                                        }





                                        modelo.consequences[21].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.pRedBC";
                                        decimal percReducaoBase_ICMS = 0;
                                        foreach (dynamic enquadramento in itensDocFiscal.enquadramentos)
                                        {
                                            if (enquadramento.dsSigla == "ICMS" && enquadramento.percReducaoBase != null)
                                            {
                                                percReducaoBase_ICMS = enquadramento.percReducaoBase ?? 0;
                                                break;
                                            }
                                        }
                                        modelo.consequences[21].value = modelo.consequences[21].value = percReducaoBase_ICMS.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                        if (itensDocFiscal != null && itensDocFiscal.percICMSDif != null)
                                        {
                                            modelo.consequences[48].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.pDif";
                                            modelo.consequences[48].value = itensDocFiscal.percICMSDif.ToString("0.00", System.Globalization.CultureInfo.GetCultureInfo("en-US"));


                                            modelo.consequences[49].variable = "NFe.infNFe.det.imposto.ICMS.ICMS51.vICMSDif";
                                            modelo.consequences[49].value = "(NFe.infNFe.det.imposto.ICMS.ICMS51.vBC*NFe.infNFe.det.imposto.ICMS.ICMS51.pICMS) * (NFe.infNFe.det.imposto.ICMS.ICMS51.pDif)";



                                        }




                                    }





                                }
                            }
                        }
                    }



















                    // Serializar o modelo em JSON
                    JsonSerializerSettings settings = new JsonSerializerSettings
                    {
                        DefaultValueHandling = DefaultValueHandling.Ignore,
                        Formatting = Formatting.Indented,
                        NullValueHandling = NullValueHandling.Ignore
                    };


                    Condition[] usedConditions = modelo.GetUsedConditions() as Condition[];
                    Consequence[] usedConsequences = modelo.GetUsedConsequences() as Consequence[];
                    legalBase[] usedLegalBase = modelo.GetUsedLegalBase() as legalBase[];

                    var obj = new
                    {
                        modelo.accountId,
                        modelo.startDate,
                        modelo.onConflict,
                        baseId = int.Parse(modelo.baseId), // Converter para um número inteiro
                        modelo.title,
                        modelo.description,
                        modelo.keywords,
                        conditions = usedConditions,
                        consequences = usedConsequences,
                        legalBase = usedLegalBase

                    };

                    string json = JsonConvert.SerializeObject(obj, settings);

                    // Função para verificar se o arquivo está sendo gravado ou em uso
                    bool isFileLocked = IsFileLocked(jsonFilePath);
                    if (!isFileLocked)
                    {
                        // Define o nome do arquivo de saída como o mesmo do arquivo de entrada
                        var outputFile = Path.Combine(outputPath, Path.GetFileName(jsonFilePath));

                        // Escrever o JSON serializado em um arquivo
                        using (FileStream fileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 4096))
                        {
                            using (StreamWriter writer = new StreamWriter(fileStream))
                            {
                                writer.Write(json);
                            }
                        }

                        Console.WriteLine("Arquivo de saída gerado com sucesso em " + outputFilePath);

                        // Move o arquivo de entrada para o diretório de processados
                        var processedFilePath = Path.Combine(processedPath, Path.GetFileName(jsonFilePath));

                        // Verifica se o arquivo de destino já existe
                        if (File.Exists(processedFilePath))
                        {
                            // Gera um nome de arquivo exclusivo adicionando um timestamp ao nome do arquivo
                            string uniqueFileName = Path.GetFileNameWithoutExtension(processedFilePath) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + Path.GetExtension(processedFilePath);
                            processedFilePath = Path.Combine(processedPath, uniqueFileName);
                        }

                        // Move o arquivo de entrada para o diretório de processados
                        File.Move(jsonFilePath, processedFilePath);


                    }



                    static bool IsFileLocked(string jsonFilePath)
                    {
                        try
                        {
                            using (var fileStream = new FileStream(jsonFilePath, FileMode.Open, FileAccess.Read, FileShare.None))
                            {
                                // O arquivo não está bloqueado
                                return false;
                            }
                        }
                        catch (IOException)
                        {
                            // O arquivo está sendo gravado ou em uso
                            return true;
                        }
                        catch (UnauthorizedAccessException)
                        {
                            // O acesso ao arquivo foi negado devido à falta de espaço em disco
                            Console.WriteLine("Sem espaço em disco, o processo não pode ser executado.");

                            // Verificar se ocorreu a décima exceção UnauthorizedAccessException
                            if (IsMaxUnauthorizedAccessException(jsonFilePath, 10))
                            {
                                // Excluir os arquivos das pastas especificadas
                                DeleteFilesFromFolders(
                                    @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Processed",
                                    @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Request\Processed",
                                    @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Responser\Processed",
                                    @"C:\Temp_Arq_Calc_Tax\Arq_Cone\IN\Erro",
                                    @"C:\Temp_Arq_Calc_Tax\Arq_Cone\IN\Processed"
                                );
                            }

                            return true;
                        }
                    }

                    static bool IsMaxUnauthorizedAccessException(string jsonFilePath, int maxCount)
                    {
                        string countFilePath = jsonFilePath + ".count";
                        int count = 0;

                        if (File.Exists(countFilePath))
                        {
                            string countStr = File.ReadAllText(countFilePath);
                            int.TryParse(countStr, out count);
                        }

                        count++;

                        File.WriteAllText(countFilePath, count.ToString());

                        return count >= maxCount;
                    }

                    static void DeleteFilesFromFolders(params string[] folderPaths)
                    {
                        foreach (string folderPath in folderPaths)
                        {
                            DirectoryInfo directory = new DirectoryInfo(folderPath);
                            FileInfo[] files = directory.GetFiles();

                            foreach (FileInfo file in files)
                            {
                                try
                                {
                                    file.Delete();
                                    Console.WriteLine("Arquivo excluído: " + file.FullName);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erro ao excluir o arquivo " + file.FullName + ": " + ex.Message);
                                }
                            }
                        }
                    }
                }


                catch (JsonReaderException ex)
                {
                    Console.WriteLine("Ocorreu um erro na desserialização do JSON: " + ex.Message);
                    Console.WriteLine("Descartando o arquivo e continuando com a execução do código.");
                    // Outras ações que você deseja realizar, como registrar o erro ou tomar medidas alternativas
                }
                catch (JsonWriterException ex)
                {
                    Console.WriteLine("Ocorreu um erro ao escrever o JSON: " + ex.Message);
                    Console.WriteLine("Descartando o arquivo e continuando com a execução do código.");
                    // Outras ações que você deseja realizar, como registrar o erro ou tomar medidas alternativas
                }


            }
        }
    }
}
































public class Modelo
{
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string accountId { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string startDate { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string onConflict { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string baseId { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string title { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string description { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string[] keywords { get; set; }

    /// <summary>
    /// /[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    /// </summary>
    ///// public legalBase[] legalBase = new legalBase[11]
    ///// {
    //// new legalBase(), new legalBase(),new legalBase(), new legalBase(),new legalBase(), 
    ///// new legalBase(),new legalBase(), new legalBase(),new legalBase(), new legalBase(),
    /////new legalBase()
    ///// };

    /// <summary>
    /// [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    /// </summary>
    //public Condition[] conditions = new Condition[6]
    ///{
    ///new Condition(), new Condition(), new Condition(),new Condition(),new Condition(),new Condition()
    ///};

    //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    //public Consequence[] consequences = new Consequence[26]
    // {
    // new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(),
    // new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(), new Consequence(),
    // new Consequence(), new Consequence(), new Consequence(),new Consequence(), new Consequence(), new Consequence()
    //  };

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public legalBase[] legalBase;

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public Condition[] conditions;


    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public Consequence[] consequences;

    public Modelo(int maxlegalBase, int maxConditions, int maxConsequences)
    {


        conditions = Enumerable.Range(0, maxConditions)
                                .Select(_ => new Condition())
                                .ToArray();


        consequences = Enumerable.Range(0, maxConsequences)
                                 .Select(_ => new Consequence())
                                 .ToArray();

        legalBase = Enumerable.Range(0, maxlegalBase)
                                 .Select(_ => new legalBase())
                                 .ToArray();


    }



    public Condition[] GetUsedConditions()
    {
        //return conditions.Where(c => !string.IsNullOrEmpty(c._operator) && !string.IsNullOrEmpty(c.variable) && !string.IsNullOrEmpty(c.variable) && !string.IsNullOrEmpty(c.value))
        //                 .ToArray();

        return conditions.Where(c => !string.IsNullOrEmpty(c._operator) && !string.IsNullOrEmpty(c.variable) && c.value != null)
                       .ToArray();

    }




    public Consequence[] GetUsedConsequences()
    {
        return consequences.Where(c => !string.IsNullOrEmpty(c.variable) && !string.IsNullOrEmpty(c.value))
                           .ToArray();
    }


    public legalBase[] GetUsedLegalBase()
    {
        return legalBase.Where(c => !string.IsNullOrEmpty(c.name) && !string.IsNullOrEmpty(c.url))
                           .ToArray();
    }



}

public class Condition
{

    [JsonProperty("operator", DefaultValueHandling = DefaultValueHandling.Ignore)]
    //[JsonProperty("operator")]
    public string _operator { get; set; }

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string variable { get; set; }

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string[] value { get; set; } = new string[1];
}

public class Consequence
{

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string variable { get; set; }

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string value { get; set; }

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string function { get; set; }
}

public class legalBase
{
    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string name { get; set; }

    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
    public string url { get; set; }

}