﻿using System;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json.Linq;

class Program
{
    static void Main()
    {
        string diretorioMasterdata = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Base_Completa";
        string diretorioIN = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN";
        string diretorioProcessados = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Base_Completa\Processed";
        string diretorioControle = @"C:\Temp_Arq_Calc_Tax\Arq_Cone\Versao_Regra";

        string versaoRegraSovosUrl = "https://rt-dufry.taxweb.com.br/taxgateway/webapi/taxrules/versioncomponent";
        string versaoTaxConeUrl = "https://api.contabilone.com/rules-engine/rule-base";

        string apiKey = "UO86dUKpK6RuOikxPkXA5aQSdLXK3xGq";
        string accountId = "224e75d8-16b0-4113-b20c-54a8576f4ccd";

        string conteudoVersaoRegraSovos = GetApiResponse(versaoRegraSovosUrl);

        string arquivoControle = Path.Combine(diretorioControle, "historico_DutyPaid.txt");
        string[] linhasControle = File.Exists(arquivoControle) ? File.ReadAllLines(arquivoControle) : new string[0];
        string conteudoVersaoRegraSovosAnterior = linhasControle.Length > 0 ? linhasControle[linhasControle.Length - 1].Split('|')[1] : string.Empty;

        if (!conteudoVersaoRegraSovos.Equals(conteudoVersaoRegraSovosAnterior))
        {
            string requestBody = $"{{\"accountId\": \"{accountId}\", \"label\": \"{conteudoVersaoRegraSovos}\"}}";
            string idResponseVersaoTaxCone = PostApiResponse(versaoTaxConeUrl, apiKey, requestBody);

            if (!string.IsNullOrEmpty(idResponseVersaoTaxCone)) // Only proceed if the API call was successful
            {
                // Atualizar a última linha do arquivo de controle com o ID da Versao_Tax_Cone
                string dataHoraAtual = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                string linhaControle = $"{dataHoraAtual}|{conteudoVersaoRegraSovos}|{idResponseVersaoTaxCone}\n";
                File.AppendAllText(arquivoControle, linhaControle);

                // Processar arquivos
                ProcessFiles(diretorioMasterdata, diretorioIN, diretorioProcessados);
                Console.WriteLine("Arquivos fracionados e versão atualizada.");
            }
            else
            {
                Console.WriteLine("Falha ao atualizar a regra fiscal, fracionamento não iniciado.");
            }
        }
        else
        {
            Console.WriteLine("Nenhuma atualização de versão necessária.");
        }
    }

    static void ProcessFiles(string sourceDir, string outputDir, string processedDir)
    {
        string[] files = Directory.GetFiles(sourceDir, "*DutyPaid*");
        foreach (string filePath in files)
        {
            string fileName = Path.GetFileName(filePath);
            using (StreamReader reader = new StreamReader(filePath, Encoding.UTF8, true, 8192))
            {
                int fileIndex = 1;
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string fractionFileName = $"{fileName}_fraction_{fileIndex}.txt";
                    string fractionFilePath = Path.Combine(outputDir, fractionFileName);
                    using (StreamWriter fractionWriter = new StreamWriter(fractionFilePath, false, Encoding.UTF8, 8192))
                    {
                        fractionWriter.WriteLine(line);
                    }
                    fileIndex++;
                }
            }
            string processedFilePath = Path.Combine(processedDir, fileName);
            File.Move(filePath, processedFilePath, true);
        }
    }

    static string GetApiResponse(string url)
    {
        using (WebClient client = new WebClient())
        {
            return client.DownloadString(url);
        }
    }

    static string PostApiResponse(string url, string apiKey, string requestBody)
    {
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = "POST";
        request.Headers.Add("x-api-key", apiKey);
        request.ContentType = "application/json";

        try
        {
            byte[] data = Encoding.UTF8.GetBytes(requestBody);
            using (Stream requestStream = request.GetRequestStream())
            {
                requestStream.Write(data, 0, data.Length);
            }

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream responseStream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(responseStream))
            {
                string responseJson = reader.ReadToEnd();
                JObject responseObject = JObject.Parse(responseJson);
                return responseObject["id"].ToString(); // Assuming the API returns an object with an 'id' field
            }
        }
        catch
        {
            return ""; // Return empty string if there's an error in response
        }
    }
}
