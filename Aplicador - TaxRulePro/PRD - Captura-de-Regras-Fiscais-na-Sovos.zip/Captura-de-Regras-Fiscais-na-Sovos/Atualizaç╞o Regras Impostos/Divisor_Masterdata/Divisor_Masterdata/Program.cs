﻿using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        string sourceDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata";
        string targetDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Base_Completa";
        string processedDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Processed";
        string searchPattern = "*masterdata*.txt";

        // Verifica se o diretório de arquivos processados existe, se não, cria-o
        if (!Directory.Exists(processedDirectory))
        {
            Directory.CreateDirectory(processedDirectory);
        }

        foreach (string filePath in Directory.GetFiles(sourceDirectory, searchPattern))
        {
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                int totalLines = lines.Length;
                int linesPerFile = totalLines / 10;
                int remainingLines = totalLines % 10;

                for (int i = 0; i < 10; i++)
                {
                    string newFileName = Path.Combine(targetDirectory, $"{Path.GetFileNameWithoutExtension(filePath)}_part{i + 1}.txt");
                    int startLine = i * linesPerFile;
                    int count = linesPerFile + (remainingLines > 0 && i == 2 ? remainingLines : 0);
                    File.WriteAllLines(newFileName, lines.Skip(startLine).Take(count));
                }

                // Move o arquivo original para a pasta de arquivos processados
                string processedFilePath = Path.Combine(processedDirectory, Path.GetFileName(filePath));
                File.Move(filePath, processedFilePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Cannot process file {filePath}: {ex.Message}");
            }
        }

        Console.WriteLine("Files have been split and moved to the processed directory successfully.");
    }
}
