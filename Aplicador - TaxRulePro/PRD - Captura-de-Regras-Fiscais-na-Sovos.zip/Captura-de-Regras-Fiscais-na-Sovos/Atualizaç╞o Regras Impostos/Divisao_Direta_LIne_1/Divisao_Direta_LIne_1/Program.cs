﻿using System;
using System.IO;
using System.Linq;
using System.Threading;

class Program
{
    static void Main()
    {
        string inputDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata";
        string outputDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN_line_1";
        string processedDirectory = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Arq_Masterdata\Processed_line_1";
        string searchKeyword = "Frontoffice_DutyPaid_MasterDataBP-202407020820141";

        while (true)
        {
            // Obtém a lista de arquivos no diretório de entrada
            string[] inputFiles = Directory.GetFiles(inputDirectory);

            if (inputFiles.Length == 0)
            {
                Console.WriteLine("Nenhum arquivo para processar. Aguardando 5 minutos...");
                Thread.Sleep(5 * 60 * 1000); // Aguarda 5 minutos antes de verificar novamente
                continue;
            }

            foreach (string inputFile in inputFiles)
            {
                string fileName = Path.GetFileNameWithoutExtension(inputFile);

                if (fileName.Contains(searchKeyword, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Processando arquivo: {inputFile}");

                    // Verificar se o diretório de destino existe, senão, criá-lo
                    if (!Directory.Exists(processedDirectory))
                    {
                        Directory.CreateDirectory(processedDirectory);
                    }

                    // Verificar se o arquivo de destino já existe e excluí-lo, se necessário
                    string processedFilePath = Path.Combine(processedDirectory, Path.GetFileName(inputFile));
                    if (File.Exists(processedFilePath))
                    {
                        File.Delete(processedFilePath);
                    }

                    // Fraciona o arquivo e grava suas frações no diretório de saída
                    SplitAndSaveFile(inputFile, outputDirectory);

                    // Move o arquivo original para o diretório de processados
                    File.Move(inputFile, processedFilePath);

                    Console.WriteLine($"Arquivo processado: {inputFile}");
                }
            }
        }
    }

    static void SplitAndSaveFile(string filePath, string outputDirectory)
    {
        string[] lines = File.ReadAllLines(filePath);

        int lineNumber = 1;
        int fileNumber = 1;
        StreamWriter currentFile = null;

        foreach (string line in lines)
        {
            string trimmedLine = line.TrimEnd(); // Remove espaços no final da linha

            if (!string.IsNullOrWhiteSpace(trimmedLine))
            {
                if (currentFile == null || lineNumber == 1)
                {
                    if (currentFile != null)
                    {
                        currentFile.Close();
                        RemoveTrailingBlankLines(outputDirectory, fileNumber - 1); // Remove linhas em branco do arquivo fracionado anterior
                    }

                    string fileName = Path.GetFileNameWithoutExtension(filePath);
                    string fileExtension = Path.GetExtension(filePath);
                    string outputFilePath = Path.Combine(outputDirectory, $"{fileName}_fraction_{fileNumber}{fileExtension}");
                    currentFile = new StreamWriter(outputFilePath);
                    fileNumber++;
                }

                currentFile.Write(trimmedLine + Environment.NewLine); // Utiliza o método Write em vez de WriteLine

                lineNumber++;

                // Define o número máximo de linhas por arquivo
                int maxLinesPerFile = 1; // Altere esse valor conforme necessário

                if (lineNumber > maxLinesPerFile)
                {
                    lineNumber = 1;
                }
            }
        }

        if (currentFile != null)
        {
            currentFile.Close();
            RemoveTrailingBlankLines(outputDirectory, fileNumber - 1); // Remove linhas em branco do último arquivo fracionado
            Console.WriteLine($"Remove linhas em branco do último arquivo fracionado");
        }
    }

    static void RemoveTrailingBlankLines(string outputDirectory, int fileNumber)
    {
        string[] filePaths = Directory.GetFiles(outputDirectory, $"*fraction_{fileNumber}*");

        foreach (string filePath in filePaths)
        {
            var lines = File.ReadAllLines(filePath);

            int lastNonBlankLine = lines.Length - 1;
            for (int i = lines.Length - 1; i >= 0; i--)
            {
                if (!string.IsNullOrWhiteSpace(lines[i]))
                {
                    lastNonBlankLine = i;
                    break;
                }
            }

            var trimmedLines = lines.Take(lastNonBlankLine + 1).ToArray();

            File.WriteAllLines(filePath, trimmedLines);

            string outputFilePath = Path.Combine(outputDirectory, $"{Path.GetFileNameWithoutExtension(filePath)}_fraction_{fileNumber}{Path.GetExtension(filePath)}");
            Console.WriteLine($"Fracionamento e salvamento de arquivo: {outputFilePath}");
        }
    }
}
