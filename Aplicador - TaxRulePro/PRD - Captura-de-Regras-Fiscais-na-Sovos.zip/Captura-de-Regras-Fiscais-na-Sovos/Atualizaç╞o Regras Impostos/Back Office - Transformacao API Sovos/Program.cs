﻿// See https://aka.ms/new-console-template for more information

using System.IO;
using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;


public class Transformacao_para_API_Sovos
{
    public static void Main(string[] args)
    {
        string fileNames = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\IN";
        string searchPattern = "*Backoffice_DutyPaid*"; // padrão de nome dos arquivos
        string[] filePaths = Directory.GetFiles(fileNames, searchPattern);

        string processado = @"C:\Temp_Arq_Calc_Tax\Arq_Gamma\Processed";

        string filestore = @"C:\Temp_Arq_Calc_Tax\Arq_Cone\Versao_Regra";
        string searchstore = "*historico_DutyPaid*"; // padrão de nome do arquivo de controle da versao de regra
        string[] filestores = Directory.GetFiles(filestore, searchstore);




        int codigo = 999; // Valor padrão do código
        string filestorePath = null; // Declaração fora do loop

        for (int attempt = 1; attempt <= 5 && codigo == 999; attempt++) // Tentar até 5 vezes ou até encontrar o código
        {
            try
            {
                if (filestores.Length > 0)
                {
                    filestorePath = filestores.Last();

                    if (IsFileLocked(filestorePath))
                    {
                        Console.WriteLine($"O arquivo {filestorePath} está sendo gravado ou em uso. Ignorando.");
                    }
                    else
                    {
                        string lastLine = File.ReadLines(filestorePath).LastOrDefault();

                        if (!string.IsNullOrEmpty(lastLine))
                        {
                            string[] lines = File.ReadAllLines(filestorePath);
                            for (int i = lines.Length - 1; i >= 0; i--)
                            {
                                string[] fields = lines[i].Split('|');
                                if (fields.Length == 3 && !string.IsNullOrWhiteSpace(fields[0]) && !string.IsNullOrWhiteSpace(fields[1]) && !string.IsNullOrWhiteSpace(fields[2]))
                                {
                                    string codigoString = fields[2].Trim();
                                    if (!string.IsNullOrEmpty(codigoString))
                                    {
                                        if (int.TryParse(codigoString, out var parsedCodigo))
                                        {
                                            codigo = parsedCodigo;
                                            break; // Encontrou a última linha com os três campos preenchidos, então sai do loop
                                        }
                                        else
                                        {
                                            Console.WriteLine("Valor inválido na segunda posição. Utilizando valor padrão.");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Erro ao acessar o arquivo {filestorePath}: {ex.Message}. Tentativa {attempt}/5. Aguardando nova tentativa...");
                // Adicionar um delay ou lógica para aguardar antes de tentar novamente
            }
        }

        Console.WriteLine($"Código encontrado: {codigo}");







        // Função para verificar se o arquivo está bloqueado
        bool IsFileLocked(string filePath)
        {
            try
            {
                using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    return false; // O arquivo não está bloqueado
                }
            }
            catch (IOException)
            {
                return true; // O arquivo está bloqueado
            }
        }








        foreach (string filePath in filePaths)
        {
            Console.WriteLine(filePath);

            if (IsFileLocked(filePath))
            {
                Console.WriteLine($"O arquivo {filePath} está sendo gravado ou em uso. Ignorando.");
                continue;
            }



            if (File.Exists(filePath))
            {
                string fileContent = File.ReadAllText(filePath);

                // O arquivo contém as informações separadas por |
                string[] userInfo = fileContent.Split('|');



                // Função para verificar se coluna NCM é nula
                string NCMString; // Mantenha como string
                if ((userInfo[0] == "LFDES" || userInfo[0] == "LFEM") &&
                    (userInfo[1] == "013" || userInfo[1] == "014" || userInfo[1] == "148" || userInfo[1] == "239") &&
                    (string.IsNullOrEmpty(userInfo[19]) || !int.TryParse(userInfo[19], out _)))
                {
                    NCMString = "33030010"; // Mantenha como string
                }
                else if (!string.IsNullOrEmpty(userInfo[19]))
                {
                    // Garante que o NCM mantenha os zeros à esquerda
                    NCMString = userInfo[19].PadLeft(8, '0');
                }
                else
                {
                    // Defina um valor padrão caso desejado quando userInfo[19] for nulo e não aplicar o código fixo.
                    // Por exemplo: NCMString = "0"; ou NCMString = algumOutroValor;
                    // Caso contrário, você pode deixar sem nada para atribuir o valor padrão "0".
                    NCMString = "0"; // Mantenha como string
                }


                string CESTString; // Mantenha como string                                   
                // Garante que o CEST mantenha os zeros à esquerda
                CESTString = userInfo[21];



                // Nova condição para definir vlUnitario e vlTotal
                double vlUnitario, vlTotal;
                if (NCMString == "22029900")
                {
                    vlUnitario = 3.85;
                    vlTotal = 3.85;
                }
                else if (NCMString == "22084000")
                {
                    vlUnitario = 26.20;
                    vlTotal = 26.20;
                }
                else if (NCMString == "22083020")
                {
                    vlUnitario = 236.03;
                    vlTotal = 236.03;
                }
                else
                {
                    vlUnitario = 10.00;
                    vlTotal = 10.00;
                }





                Rootobject[] Rootobject = new Rootobject[] {
                new Rootobject {

        cdTipo = userInfo[2],
        dtEmissao = "",

        destinatario = new destinatario {
            pessoaJuridica = userInfo[6],
            simplesNac = "N",
            contribuinteICMS = userInfo[7],
            contribuinteCOFINS = "S",
            contribuintePIS = "S",
            contribuinteII = "N",
            contribuinteIPI = "N",
            contribuinteISS = "N",
            contribuinteST = "N",
            cdPais =  userInfo[1] == "013"||userInfo[1] == "048"||userInfo[1] == "148"  ? "845" : "105",
            cdMunicipio = userInfo[16],
            uf = userInfo[17],
            cnpj = userInfo[14],
            inscricaoEstadual = userInfo[15],
            cdAtividadeEconomica = new string[] { userInfo[18] },
        },

       emitente = new emitente {
            pessoaJuridica = userInfo[5],
            cdAtividadeEconomica = new string[] { userInfo[13] },
            cnpj = userInfo[9],
            inscricaoEstadual= userInfo[10],
            simplesNac = "N",
            regTribDiferenciado = new string[] { userInfo[0] },
            contribuinteCOFINS = "S",
            contribuintePIS = "S",
            contribuinteICMS = "S",
            contribuinteII = "N",
            contribuinteIPI = "N",
            contribuinteISS = "N",
            contribuinteST = "N",
            cdPais = "105",
            cdMunicipio = userInfo[11],
            uf = userInfo[12],
            nome = "",
            inscricaoMunicipal = ""
            },
        itensDocFiscal = new ItemDocFiscal[] {
            new ItemDocFiscal {
                prodItem = new prodItem {
                    // Garante que o CEST mantenha os zeros à esquerda
                    CEST = string.IsNullOrEmpty(CESTString) ? string.Empty : CESTString.PadLeft(7, '0'),
                cdOrigem = string.IsNullOrEmpty(userInfo[25]) ? 2 : Int32.Parse(userInfo[25]),
                    codigo = codigo,
                    descricao = "Consulta Impostos",
                    EAN = "SEM GTIN",

                  NCM = NCMString,



                exNCM = userInfo[20],
                    fabricacao = "1",
                    aplicacao = "C"
                },
                cdItemDocFiscal = Int32.Parse(userInfo[22]),
                vlAliquotaICMSOperacaoAnterior = string.IsNullOrEmpty(userInfo[23]) ? string.Empty : userInfo[23].Replace(',', '.'),
                CDU1 = string.IsNullOrEmpty(userInfo[24]) || userInfo[24] == "SP"  ? null : userInfo[24],
                unidade = "UN",
                 vlTotal = vlTotal,
                vlUnitario = vlUnitario,
                vlDesconto = 0.00,
                qtItemDocFiscal = 1.0,
                qtTributaria = 1.0,
                qtTributariaUnidade = "UN",
                cdClassificacao = "M",
                deduzCEST = "N",
                deduzCFOP = "S",
                deduzCSTCOFINS = "S",
                deduzCSTICMS = "S",
                deduzCSTIPI = "S",
                deduzCSTPIS = "S"

            }
        },
        naturezaOperacao = userInfo[1],
        indConsumidorFinal = userInfo[3],
        indPresenca = userInfo[4],
        tpDocFiscal = "FT",

        tpCalculo = userInfo[1] == "001" || userInfo[1] == "069"  ? "REC" : "TAX",


                versaoNFe = "4.00",
        geraLog = "N",
        modelo = Int32.Parse("55"),
        serie = Int32.Parse("100"),
        numero = Int32.Parse("1"),

            CalcParam = new CalcParam {
                mdArred = "A",
                geraInc = "N"
            }
        }
};

                // Criar um objeto que contém todas as instâncias que deseja serializar
                var data = new
                {
                    Rootobject = Rootobject
                };



                // Serializar o objeto contendo todas as instâncias
                string json = JsonConvert.SerializeObject(data);

                ////string json = System.Text.Json.JsonSerializer.Serialize(data);

                // Converter o objeto Rootobject para uma string JSON
                //string json = JsonConvert.SerializeObject(Rootobject);

                // Remover o primeiro caractere '{' da string JSON
                //json = json.Substring(15, json.Length - 2);
                json = json.Substring(14);
                json = json.Substring(0, json.Length - 1);

                // Remover qualquer texto adicional da string JSON
                json = json.Trim();

                // Converter a string JSON atualizada para um objeto Rootobject
                //Rootobject updatedRootobject = JsonConvert.DeserializeObject<Rootobject>(json);


                string path = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Request";
                string fileName = Path.GetFileName(filePath);
                string outputPath = Path.Combine(processado, fileName);
                File.Move(filePath, outputPath, true);

                string filePathr = Path.Combine(path, fileName + ".json");


                using (StreamWriter writer = new StreamWriter(filePathr, false))
                {
                    writer.Write(json);
                }
            }
            else
            {
                Console.WriteLine("O arquivo não existe no diretório especificado.");


            }
        }
    }




    [JsonObject(NamingStrategyType = typeof(CamelCaseNamingStrategy), NamingStrategyParameters = new object[] { true, false })]
    public class Rootobject

    {
        public string cdTipo { get; set; }
        public string dtEmissao { get; set; }
        public destinatario destinatario { get; set; }
        public emitente emitente { get; set; }
        public ItemDocFiscal[] itensDocFiscal { get; set; }
        public CalcParam CalcParam { get; set; }
        public string geraLog { get; set; }
        public string naturezaOperacao { get; set; }
        public string tpCalculo { get; set; }
        public string indConsumidorFinal { get; set; }
        public string indPresenca { get; set; }
        public int numero { get; set; }
        public int serie { get; set; }
        public string tpDocFiscal { get; set; }
        public string versaoNFe { get; set; }
        public bool docFiscalTeste { get; set; }
        public int modelo { get; set; }
    }

    public class destinatario
    {
        public string pessoaJuridica { get; set; }
        public string[] cdAtividadeEconomica { get; set; }
        public string simplesNac { get; set; }
        public string contribuinteICMS { get; set; }
        public string contribuinteCOFINS { get; set; }
        public string contribuinteII { get; set; }
        public string contribuinteIPI { get; set; }
        public string contribuinteISS { get; set; }
        public string contribuintePIS { get; set; }
        public string contribuinteST { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string cpf { get; set; }
        public string cnpj { get; set; }
        public string cdPais { get; set; }
        public string cdMunicipio { get; set; }
        public string uf { get; set; }
        public string inscricaoEstadual { get; set; }
    }

    public class emitente
    {
        public string pessoaJuridica { get; set; }
        public string[] cdAtividadeEconomica { get; set; }
        public string cnpj { get; set; }
        public string inscricaoEstadual { get; set; }
        public string nome { get; set; }
        public string simplesNac { get; set; }
        public string[] regTribDiferenciado { get; set; }
        public string contribuinteCOFINS { get; set; }
        public string contribuinteICMS { get; set; }
        public string contribuinteII { get; set; }
        public string contribuinteIPI { get; set; }
        public string contribuinteISS { get; set; }
        public string contribuintePIS { get; set; }
        public string contribuinteST { get; set; }
        public string cdPais { get; set; }
        public string cdMunicipio { get; set; }
        public string uf { get; set; }
        public string inscricaoMunicipal { get; set; }
    }

    public class ItemDocFiscal
    {
        public prodItem prodItem { get; set; }
        public int cdItemDocFiscal { get; set; }
        public string vlAliquotaICMSOperacaoAnterior { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string CDU1 { get; set; }
        public string unidade { get; set; }
        public double vlTotal { get; set; }
        public double vlUnitario { get; set; }
        public double vlDesconto { get; set; }
        public double qtItemDocFiscal { get; set; }
        public double qtTributaria { get; set; }
        public string qtTributariaUnidade { get; set; }
        public string cdClassificacao { get; set; }
        public string deduzCEST { get; set; }
        public string deduzCFOP { get; set; }
        public string deduzCSTCOFINS { get; set; }
        public string deduzCSTICMS { get; set; }
        public string deduzCSTIPI { get; set; }
        public string deduzCSTPIS { get; set; }
    }

    public class prodItem
    {
        public string? CEST { get; set; }
        public int cdOrigem { get; set; }
        public int codigo { get; set; }
        public string descricao { get; set; }
        public string EAN { get; set; }
        public string NCM { get; set; }
        public string exNCM { get; set; }
        public string fabricacao { get; set; }
        public string aplicacao { get; set; }
    }

    public class CalcParam
    {
        public string mdArred { get; set; }
        public string geraInc { get; set; }
    }
}

