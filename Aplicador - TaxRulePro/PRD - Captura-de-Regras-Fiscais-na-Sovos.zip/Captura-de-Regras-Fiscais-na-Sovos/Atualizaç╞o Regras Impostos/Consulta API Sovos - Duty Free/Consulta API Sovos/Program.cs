﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        // Define o caminho dos arquivos de entrada, saída e processados
        var inputPath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Request";
        var outputPath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Responser";
        var processedPath = @"C:\Temp_Arq_Calc_Tax\Arq_Sovos\Request\Processed";

        // Define o padrão de busca para os arquivos de entrada
        string searchPattern = "*DutyFree*";

        // Busca os arquivos que correspondem ao padrão de busca
        string[] inputFilePaths = Directory.GetFiles(inputPath, searchPattern);

        // Cria um objeto HttpClient
        using var client = new HttpClient();

        // Define a URL da API e os headers para enviar na solicitação POST  
        var url = "https://rt-dufry-dutyfree.taxweb.com.br/taxgateway/webapi/taxrules/calctaxesbulk"; ///--->> PRD
        ///var url = "https://rt-dufry-homolog.taxweb.com.br/taxgateway/webapi/taxrules/calctaxesbulk"; ///--->> HML
        var headers = new MediaTypeHeaderValue("application/json");

        // Lista para armazenar as tarefas de envio de solicitação POST
        List<Task> postTasks = new List<Task>();

        ///    foreach (var inputFilePath in inputFilePaths)
        ///   {
        ///       postTasks.Add(ProcessFileAsync(inputFilePath));
        ///await Task.Delay(300); // Pausa de tres milissegundos
        ///   }

        // Aguarda a conclusão de todas as tarefas de envio de solicitação POST
        ////  await Task.WhenAll(postTasks);





        for (int i = 0; i < inputFilePaths.Length; i++)
        {
            var inputFilePath = inputFilePaths[i];

            if (IsFileLocked(inputFilePath))
            {
                Console.WriteLine($"O arquivo {inputFilePath} está sendo gravado ou em uso. Ignorando.");
                continue;
            }

            postTasks.Add(ProcessFileAsync(inputFilePath));
            Console.WriteLine($"[Consulta API Sovos Duty Paid] ao processar o arquivo {inputFilePath}");
            await Task.Delay(100); // Pausa de cem milissegundos
        }

        await Task.WhenAll(postTasks);

        async Task ProcessFileAsync(string inputFilePath)
        {
            // Lê o arquivo de entrada como uma string
            var jsonContent = await File.ReadAllTextAsync(inputFilePath);

            // Define o nome do arquivo de saída como o mesmo do arquivo de entrada
            var outputFilePath = Path.Combine(outputPath, Path.GetFileName(inputFilePath));

            var content = new StringContent(jsonContent);
            content.Headers.ContentType = headers;

            var response = await client.PostAsync(url, content);
            var responseBody = await response.Content.ReadAsStringAsync();

            // Verifica se a solicitação foi bem sucedida (status code 200-299)
            if (response.IsSuccessStatusCode)
            {
                byte[] responseBodyBytes = Encoding.UTF8.GetBytes(responseBody);

                // Salva a resposta no arquivo de saída
                File.WriteAllBytes(outputFilePath, responseBodyBytes);

                // Move o arquivo de entrada para o diretório de processados
                var processedFilePath = Path.Combine(processedPath, Path.GetFileName(inputFilePath));
                File.Move(inputFilePath, processedFilePath, true);
                Console.WriteLine($"[Consulta API Sovos Duty Free] Processado com sucesso Status code: {response.StatusCode}  {outputFilePath}");
            }

            else
            {
                Console.WriteLine($"[Consulta API Sovos Duty Free] Erro ao processar o arquivo {inputFilePath}. Status code: {response.StatusCode} {outputFilePath}");
            }
        }



        bool IsFileLocked(string filePath)
        {
            try
            {
                using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    return false; // O arquivo não está bloqueado
                }
            }
            catch (IOException)
            {
                return true; // O arquivo está bloqueado
            }
        }


    }
}
